rm(list=ls(all=T))

library(foreign)
library(survival)    
library(survminer)
library(readstata13)
library(simPH)


###########################################################
###########################################################
########    Backing Despots: Foreign Aid and      #########
########   the Survival of Autocratic Regimes     #########
########                 (R Code)                 #########
########           Camilo Nieto-Matiz             #########
########              Luis Schenoni               #########
###########################################################
###########################################################


# set wd
setwd("~/Box Sync/Foreign Aid and Autocracies/Data/")

# open file
peq <- read.dta13("peq.dta")





#================================
#========     Models     ========     
#================================



#================================
#         aid per capita
#================================

# no interaction
pc1<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~lnaidpercapita_lag+
              lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
              data=peq)
summary(pc1)
test1 <- cox.zph(pc1);test1

# x proportion democratic aid
pc2<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~lnaidpercapita_lag*propdemoc_lag+
             lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq)
summary(pc2)
test2 <- cox.zph(pc2);test2

# x US leverage
pc3<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~lnaidpercapita_lag*shierarchy_lag+
            lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
            cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq) 

summary(pc3)
test3 <- cox.zph(pc3);test3


xtable(test1$table)
xtable(test2$table)
xtable(test3$table)


#================================
#             total aid
#================================

# no interaction
to1<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~lnaidtotallag+
              lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq)
summary(to1)
test4 <- cox.zph(to1);test4

# x proportion democratic aid
to2<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~lnaidtotallag*propdemoc_lag+
              lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq)
summary(to2)
test5 <- cox.zph(to2);test5

# x US leverage
to3<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~lnaidtotallag*shierarchy_lag+
              lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq) 
summary(to3)
test6 <- cox.zph(to3);test6

# latex table
screenreg(list(to1,to2,to3), reorder.coef = c(1,8,10,7,9,2,3,4,5,6), 
       custom.coef.names=c("Total aid","Coup", "Oil", "Growth", "Population", "GDP pc", "Democratic aid", 
                           "Total aid x democratic aid", "US leverage", "Total aid x US leverage"),
       custom.note = "Total aid is the log of a country's foreign aid. Democratic aid is the proportion
       of aid coming from democratic donors in a given year. US leverage is a continuous measure capturing the extent to which
       a country is dependent on the United States.")

#================================
#            aid/gdp
#================================

# no interaction
pr1<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~aidgdp_lag+
             lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq)
summary(pr1)
test7 <- cox.zph(pr1);test7

# x proportion democratic aid
pr2<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~aidgdp_lag*propdemoc_lag+
             lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq)
summary(pr2)
test8 <- cox.zph(pr2);test8

# x US leverage
pr3<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~aidgdp_lag*shierarchy_lag+
             lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq) 
summary(pr3)
test9 <- cox.zph(pr3);test9


# latex table
screenreg(list(pr1,pr2,pr3), reorder.coef = c(1,8,10,7,9,2,3,4,5,6), 
       custom.coef.names=c("Total aid","Coup", "Oil", "Growth", "Population", "GDP pc", "Democratic aid", 
                           "Total aid x democratic aid", "US leverage", "Total aid x US leverage"))


#================================
#================================


# aid pc X democratic aid pc
r2_1<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~log(aidpcdem_lag+1):lnaidpercapita_lag:log(pop1_lag)+
             log(aidpcdem_lag+1)+lnaidpercapita_lag+
           #  lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
             cluster(cowcode)+strata(coldwar)+cluster(year),
           data=peq)
summary(r2_1)
r2t1 <- cox.zph(r2_1);r2t1

# democratic aid pc X autocratic aid pc
r2_2<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~log(aidpcdem_lag+1)*log(aidpcaut_lag+1)+
              lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq)
summary(r2_2)
r2t2 <- cox.zph(r2_2);r2t2


r2_1<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~lnaidpercapita_lag*propdemoc_lag+
             # lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq)
summary(r2_1)

r2_1<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~log(aidpcdem_lag+1)+log(pop1_lag+1)*log(aidpcdem_lag+1)+
              # lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
              cluster(cowcode)+strata(coldwar)+cluster(year),
            data=peq)
summary(r2_1)


#================================
#========     Plots     ========     
#================================



# democratic aid
p1<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~lnaidpercapita_lag*propdemoc_lag+
             lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
             cluster(cowcode)+strata(coldwar)+cluster(year),
           data=peq)

p2<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~propdemoc_lag*lnaidpercapita_lag+
             lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
             cluster(cowcode)+strata(coldwar)+cluster(year),
           data=peq)

Sim1 <- coxsimInteract(p1, b1 = "lnaidpercapita_lag", b2 = "propdemoc_lag",
                       qi = "Marginal Effect",
                       X2 = c(0,1, by = .1), nsim = 1000,
                       extremesDrop = F, expMarg = F)
p1<-simGG(Sim1)+xlab('Democratic aid (proportion)')+ylab('Marginal effect of foreign aid')

Sim2 <- coxsimInteract(p2, b2 = "lnaidpercapita_lag", b1 = "propdemoc_lag",
                       qi = "Marginal Effect",
                       X2 = c(-2,15, by = .1), nsim = 1000,
                       extremesDrop = F, expMarg = F)
p2<-simGG(Sim2)+xlab('Foreign aid')+ylab('Marginal effect of democratic aid (proportion)')


# plot both
png("mar_fx1.png", width = 16, height = 8, units = 'in', res = 300)
multiplot(p1,p2)
dev.off()




# US hierarchy
p3<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~lnaidpercapita_lag*shierarchy_lag+
             lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
             cluster(cowcode)+strata(coldwar)+cluster(year),
           data=peq) 

p4<-coxph(Surv(as.numeric(gwf_startdate), as.numeric(gwf_enddate), gwf_fail)~shierarchy_lag*lnaidpercapita_lag+
             lagcoup+log(lagoil+1)+log(growth+1)+pop2+log(gdppc+1)+
             cluster(cowcode)+strata(coldwar)+cluster(year),
           data=peq) 

Sim3 <- coxsimInteract(p3, b1 = "lnaidpercapita_lag", b2 = "shierarchy_lag",
                       qi = "Marginal Effect",
                       X2 = c(0,5, by = 1), nsim = 10000,
                       extremesDrop = T, expMarg = F)
p3<-simGG(Sim3)+xlab('US Leverage')+ylab('Marginal effect of foreign aid')

Sim4 <- coxsimInteract(p4, b2 = "lnaidpercapita_lag", b1 = "shierarchy_lag",
                       qi = "Marginal Effect",
                       X2 = c(-2,15, by = 1), nsim = 10000,
                       extremesDrop = T, expMarg = F)
p4<-simGG(Sim4)+xlab('Foreign aid')+ylab('Marginal effect of US leverage')


# plot both
png("mar_fx2.png", width = 16, height = 8, units = 'in', res = 300)
multiplot(p2,p4)
dev.off()


#plot surface
png("surfaceplot_new.png", width = 8, height = 8, units = 'in', res = 300)
DAintfun(pc3, c("lnaidpercapita_lag","shierarchy_lag"),
         xlab = 'Foreign Aid',
         ylab = 'Leverage',
         zlab = 'Pr. of Failure',
         theta = -120, phi = 20)
dev.off()












##########################
#######   PLOTS   ########
##########################

###amount of aid received by each autocracy
d1<-ddply(peq, .(gwf_country), summarize,  aid=mean(aidtotal))
ggplot(d1, aes(reorder(gwf_country, aid), aid))+
  geom_bar(stat="identity")+
  geom_hline(aes(yintercept=mean(d1$aid)), color="red", size=0.4)+
  coord_flip()+theme(axis.text.y = element_text(size=rel(0.6)))



ggplot(peq, aes(reorder(gwf_country, log(aidtotal)), log(aidtotal)))+
  geom_bar(stat="identity")+coord_flip()+theme(axis.text.y = element_text(size=rel(0.6)))

ggplot(aiddata1, aes(year, log(commitment)))+
  geom_smooth(aes(group = recipient), method = "lm", se = FALSE)





 
