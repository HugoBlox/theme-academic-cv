
#=============================================================#
#                     Camilo Nieto-Matiz                      #
#                                                             # 
#        'Democracy in the Countryside: The Rural Sources     #
#         of Violence against Voters in Colombia'             #
#                                                             #
#             Journal of Peace Research, 2018                 #
#=============================================================#




rm(list=ls(all=T))

#set working directory
setwd("~/Box Sync/Electoral Violence/Paper/Data-Land and Politics")

#load libraries
library(foreign)
library(readstata13)
library(plyr)
library(ggplot2)
library(sandwich)
library(lmtest)
library(AER)
library(arm)





#import data 
dat <- read.dta13("finaldataJPR.dta")        



#======================================
#                tables               #
#======================================

## summary statistics.
## replicates table I (main document)

sum.tab<- subset(dat, select=c(elecviol, fraude, aptitud, g_prop, regional, FARCpr, ELNpr, AUCpr, 
                              contested,competencia, lagrefuerzos, coca, popdens));summary(sum.tab)


#======================================
#       first stage models            #
#======================================

## first-stage regression 'by hand'.
## replicates table II (main document)


## MODEL 1
m1<-lm(g_prop~aptitud+regional+contested+competencia+coca+
         popdens+lagrefuerzos+factor(coddepto)+factor(ano),data=dat)
first.1<- coeftest(m1, vcov = vcovHC(m1, "HC0")); first.1

## MODEL 2
m2<-lm(g_prop~aptitud*contested+regional+competencia+coca+
         popdens+lagrefuerzos+factor(coddepto)+factor(ano),data=dat)
first.2<- coeftest(m2, vcov = vcovHC(m2, "HC0")); first.2

## MODEL 3
m3<-lm(g_prop~aptitud*actorpr+regional+contested+competencia+coca+
         popdens+lagrefuerzos+factor(coddepto),data=dat)
first.3<- coeftest(m3, vcov = vcovHC(m3, "HC0")); first.3 





#======================================
#              2SLS models            #
#======================================

## electoral violence models
## replicates results from Table III (main document)

## MODEL 1 
iv1<-ivreg(elecviol~ g_prop+contested+competencia+regional+lagrefuerzos+coca+
             popdens+factor(coddepto)+factor(ano)|
             aptitud+contested+competencia+lagrefuerzos+coca+
             regional+popdens+factor(coddepto)+factor(ano), data=dat)
summary (iv1, vcov = sandwich , diagnostics = TRUE)


## MODEL 2
iv2<-ivreg(elecviol~ g_prop*contested+regional+competencia+lagrefuerzos+coca+
             popdens+factor(coddepto)+factor(ano) | 
             aptitud*contested+regional+competencia+lagrefuerzos+coca+
             popdens+factor(coddepto)+factor(ano), data=dat)
summary(iv2, vcov=sandwich, diagnostics = TRUE )


## MODEL 3
iv3<-ivreg(elecviol~actorpr*g_prop+regional+competencia+lagrefuerzos+coca+
             popdens+factor(coddepto)+factor(ano)| 
             aptitud*actorpr+regional+competencia+lagrefuerzos+coca+
             popdens+factor(coddepto)+factor(ano), data=dat)
summary(iv3, vcov = sandwich , diagnostics = TRUE)


## electoral fraud models
## replicates results from Table IV (main document)

## MODEL 1 - armed group dummy | only fraud 
iv1.fraud<-ivreg(fraude~ g_prop*contested+regional+competencia+lagrefuerzos+coca+
                   popdens+factor(coddepto)+factor(ano) | 
                   aptitud*contested+regional+competencia+lagrefuerzos+coca+
                   popdens+factor(coddepto)+factor(ano), data=dat)
summary(iv1.fraud, vcov=sandwich, diagnostics = TRUE )


## MODEL 2 - armed group dummy | electoral fraud AND electoral violence
iv1.both<-ivreg(both~ g_prop*contested+regional+competencia+lagrefuerzos+coca+
                   popdens+factor(coddepto)+factor(ano) | 
                   aptitud*contested+regional+competencia+lagrefuerzos+coca+
                   popdens+factor(coddepto)+factor(ano), data=dat)
summary(iv1.both, vcov=sandwich, diagnostics = TRUE )


## MODEL 3 - disaggregated armed group | only fraud 
iv2.fraud<-ivreg(fraude ~ g_prop*actorpr+regional+competencia+lagrefuerzos+coca+
                   popdens+factor(coddepto)+factor(ano) | 
                   aptitud*actorpr+regional+competencia+lagrefuerzos+coca+
                   popdens+factor(coddepto)+factor(ano), data=dat)
summary(iv2.fraud, vcov=sandwich, diagnostics = TRUE )


## MODEL 4 - disaggregated armed group | electoral fraud AND electoral violence
iv2.both<-ivreg(both~ g_prop*actorpr+competencia+lagrefuerzos+coca+
                   popdens+factor(coddepto)+factor(ano) | 
                   aptitud*actorpr+regional+competencia+lagrefuerzos+coca+
                   popdens+factor(coddepto)+factor(ano), data=dat)
summary(iv2.both, vcov=sandwich, diagnostics = TRUE )










