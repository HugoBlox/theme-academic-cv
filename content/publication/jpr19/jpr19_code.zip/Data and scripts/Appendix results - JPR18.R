
#=============================================================#
#                     Camilo Nieto-Matiz                      #
#                                                             # 
#        'Democracy in the Countryside: The Rural Sources     #
#         of Violence against Voters in Colombia'             #
#                                                             #
#                          APPENDIX                           #
#                                                             #
#             Journal of Peace Research, 2018                 #
#                                                             #
#=============================================================#




rm(list=ls(all=T))

#set working directory
setwd("~/Box Sync/Electoral Violence/Paper/Data-Land and Politics")

#load libraries
library(foreign)
library(readstata13)
library(plyr)
library(ggplot2)
library(sandwich)
library(lmtest)
library(AER)
library(arm)





#import data 
dat <- read.dta13("finaldataJPR.dta")        





#======================================
#        Negative Binomial            #
#======================================

## replicates results from Table I (Appendix)

# MODEL 1 - no interaction | electoral violence
fe1<-glm.nb(elecviol~ laggini+contested+regional+competencia+lagrefuerzos+
              coca+popdens+factor(coddepto)+factor(ano),
            data=dat)
coeftest(fe1, vcov = vcovHC(fe1, "HC0")) 

# MODEL 2 - armed group dummy | electoral violence
fe2<-glm.nb(elecviol~ laggini*contested+regional+competencia+lagrefuerzos+
              coca+popdens+factor(coddepto)+factor(ano),
            data=dat)
coeftest(fe2, vcov = vcovHC(fe2, "HC0")) 

# MODEL 3 - disaggregated armed group | electoral violence
fe3<-glm.nb(elecviol~actorpr*laggini+regional+competencia+lagrefuerzos+coca+
              popdens+factor(coddepto)+factor(ano), data=dat)
coeftest(fe3, vcov = vcovHC(fe3, "HC0")) 

# MODEL 4 - no interaction | electoral fraud
fr1<-glm.nb(fraude~ laggini+contested+regional+competencia+lagrefuerzos+
              coca+popdens+factor(coddepto)+factor(ano),
            data=dat)
coeftest(fr1, vcov = vcovHC(fr1, "HC0")) 

# MODEL 5 - armed group dummy | electoral fraud
fr2<-glm.nb(fraude~ laggini*contested+regional+competencia+lagrefuerzos+
              coca+popdens+factor(coddepto)+factor(ano),
            data=dat)
coeftest(fr2, vcov = vcovHC(fr2, "HC0")) 

# MODEL 6 - disaggregated armed group | electoral fraud
fr3<-glm.nb(fraude~actorpr*laggini+regional+competencia+lagrefuerzos+coca+
              popdens+factor(coddepto)+factor(ano), data=dat)
coeftest(fr3, vcov = vcovHC(fr3, "HC0")) 

# MODEL 7 - no interaction | electoral fraud AND electoral violence
b1<-glm.nb(both~ laggini+contested+regional+competencia+lagrefuerzos+
             coca+popdens+factor(coddepto)+factor(ano),
           data=dat)
coeftest(b1, vcov = vcovHC(b1, "HC0")) 

# MODEL 8 - armed group dummy | electoral fraud AND electoral violence
b2<-glm.nb(both~ laggini*contested+regional+competencia+lagrefuerzos+
             coca+popdens+factor(coddepto)+factor(ano),
           data=dat)
coeftest(b2, vcov = vcovHC(b2, "HC0")) 

# MODEL 9 - disaggregated armed group | electoral fraud AND electoral violence
b3<-glm.nb(both~actorpr*laggini+regional+competencia+lagrefuerzos+coca+
             popdens+factor(coddepto)+factor(ano), data=dat)
coeftest(b3, vcov = vcovHC(b3, "HC0")) 




#======================================
#                 OLS                 #
#======================================

## replicates results from Table II (Appendix)

# MODEL 1 - no interaction | electoral violence
ols1<-lm(elecviol~ laggini+contested+regional+competencia+lagrefuerzos+
           coca+popdens+factor(coddepto)+factor(ano),
         data=dat)
coeftest(ols1, vcov = vcovHC(ols1, "HC0")) 

# MODEL 2 - armed group dummy | electoral violence
ols2<-lm(elecviol~ laggini*contested+regional+competencia+lagrefuerzos+
           coca+popdens+factor(coddepto)+factor(ano),
         data=dat)
coeftest(ols2, vcov = vcovHC(ols2, "HC0")) 

# MODEL 3 - disaggregated armed group | electoral violence
ols3<-lm(elecviol~actorpr*laggini+regional+competencia+lagrefuerzos+coca+
           popdens+factor(coddepto)+factor(ano), data=dat)
coeftest(ols3, vcov = vcovHC(ols3, "HC0")) 



## replicates results from Table III (Appendix)

# MODEL 1 - no interaction | electoral fraud
ols4<-lm(fraude~ laggini+contested+regional+competencia+lagrefuerzos+
           coca+popdens+factor(coddepto)+factor(ano),
         data=dat)
coeftest(ols4, vcov = vcovHC(ols4, "HC0")) 

# MODEL 2 - armed group dummy | electoral fraud
ols5<-lm(fraude~ laggini*contested+regional+competencia+lagrefuerzos+
           coca+popdens+factor(coddepto)+factor(ano),
         data=dat)
coeftest(ols5, vcov = vcovHC(ols5, "HC0")) 

# MODEL 3 - disaggregated armed group | electoral fraud
ols6<-lm(fraude~actorpr*laggini+regional+competencia+lagrefuerzos+coca+
           popdens+factor(coddepto)+factor(ano), data=dat)
coeftest(ols6, vcov = vcovHC(ols6, "HC0")) 

# MODEL 4 - no interaction | electoral fraud AND electoral violence
ols7<-lm(both~ laggini+contested+regional+competencia+lagrefuerzos+
           coca+popdens+factor(coddepto)+factor(ano),
         data=dat)
coeftest(ols7, vcov = vcovHC(ols7, "HC0")) 

# MODEL 5 - armed group dummy | electoral fraud AND electoral violence
ols8<-lm(both~ laggini*contested+regional+competencia+lagrefuerzos+
           coca+popdens+factor(coddepto)+factor(ano),
         data=dat)
coeftest(ols8, vcov = vcovHC(ols8, "HC0")) 

# MODEL 6 - disaggregated armed group | electoral fraud AND electoral violence
ols9<-lm(both~actorpr*laggini+regional+competencia+lagrefuerzos+coca+
           popdens+factor(coddepto)+factor(ano), data=dat)
coeftest(ols9, vcov = vcovHC(ols9, "HC0")) 





#=================================================
#          IV controlling for pop. size          #
#=================================================


## electoral violence models
## replicates results from Table IV (Appendix)

## MODEL 1 
p1<-ivreg(elecviol~ g_prop+contested+competencia+regional+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano)|
            aptitud+contested+competencia+lagrefuerzos+coca+
            regional+log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano), data=dat)
summary (p1, vcov = sandwich , diagnostics = TRUE)

## MODEL 2
p2<-ivreg(elecviol~ g_prop*contested+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano) | 
            aptitud*contested+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano), data=dat)
summary(p2, vcov=sandwich, diagnostics = TRUE )

## MODEL 3
p3<-ivreg(elecviol~actorpr*g_prop+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano)| 
            aptitud*actorpr+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano), data=dat)
summary(p3, vcov = sandwich , diagnostics = TRUE)




## replicates results from Table V (Appendix)
## MODEL 1 
p4<-ivreg(fraude~ g_prop+contested+competencia+regional+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano)|
            aptitud+contested+competencia+lagrefuerzos+coca+
            regional+log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano), data=dat)
summary (p4, vcov = sandwich , diagnostics = TRUE)


## MODEL 2
p5<-ivreg(fraude~ g_prop*contested+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano) | 
            aptitud*contested+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano), data=dat)
summary(p5, vcov=sandwich, diagnostics = TRUE)


## MODEL 3
p6<-ivreg(fraude~actorpr*g_prop+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano)| 
            aptitud*actorpr+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano), data=dat)
summary(p6, vcov = sandwich , diagnostics = TRUE)


## MODEL 4 
p7<-ivreg(both~ g_prop+contested+competencia+regional+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano)|
            aptitud+contested+competencia+lagrefuerzos+coca+
            regional+log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano), data=dat)
summary (p7, vcov = sandwich , diagnostics = TRUE)


## MODEL 5
p8<-ivreg(both~ g_prop*contested+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano) | 
            aptitud*contested+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano), data=dat)
summary(p8, vcov=sandwich, diagnostics = TRUE )


## MODEL 6
p9<-ivreg(both~actorpr*g_prop+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano)| 
            aptitud*actorpr+regional+competencia+lagrefuerzos+coca+
            log(pobl_tot+1)+popdens+factor(coddepto)+factor(ano), data=dat)
summary(p9, vcov = sandwich , diagnostics = TRUE)





