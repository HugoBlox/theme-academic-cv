
#=============================================================#
#                     Camilo Nieto-Matiz                      #
#                                                             # 
#        'Democracy in the Countryside: the Rural Sources     #
#         of Violence against Voters in Colombia'             #
#                                                             #
#             Journal of Peace Research, 2018                 #
#=============================================================#


rm(list=ls(all=T))

#set working directory
setwd("~/Box Sync/Electoral Violence/Paper/Data-Land and Politics")

#load libraries
library(foreign)
library(readstata13)
library(doBy)
library(ggplot2)
library(scales)
library(rgdal)
library(plyr)

#import data
dat<-read.dta13("finaldataJPR.dta")        


#======================================
#                 maps                #
#======================================



## shapefiles
## pull shapefiles - municipalities
mpios.shape <- readOGR(dsn="/Users/camilo1/Box Sync/Data/Colombia/COL Adm/mpio",
                       layer="mpio")
mpios.shape <- spTransform(mpios.shape, CRS("+proj=longlat +datum=WGS84" ))
mpios.shape <- fortify(mpios.shape, region="MPIOS")
mpios.shape$id<-as.numeric(mpios.shape$id)
mpios.shape <- subset(mpios.shape, long>-80)


## variables
## import land concentration and soil quality into data frame
land <- summaryBy(g_prop+aptitud ~ codmpio, FUN=c(mean), data=dat, na.rm=T)
colnames(land)[1]<-"id"

## import electoral violence and fraud into data frame
ev <- summaryBy(elecviol+fraude ~ codmpio, FUN=c(sum), data=dat, na.rm=T)
colnames(ev)[1]<-"id"



## merge shapefiles and variables
plotdata <- join(mpios.shape, land, by='id', type="left", match="all")
plotdata <- join(plotdata, ev, by='id', type="left", match="all")



#convert electoral violence and fraud into dummies
plotdata$evd<-0
plotdata$evd[which(plotdata$elecviol.sum > 0)]<-1
plotdata$efd<-0
plotdata$efd[which(plotdata$fraude.sum > 0)]<-1



## customize ggplot theme
theme_noline <- theme(axis.text.x = element_blank(),
                      axis.text.y = element_blank(),
                      axis.ticks = element_blank(),
                      axis.title.x=element_blank(),
                      axis.title.y=element_blank(),
                      panel.border = element_blank(), 
                      panel.grid.major = element_blank(),
                      panel.grid.minor = element_blank(),
                      legend.title= element_text(size = 15),
                      legend.text=element_text(size=15),
                      plot.title = element_text(hjust = 0.5))




#===========#
## map it! ##
#===========#

## electoral violence
## generates left-hand map from Figure 1

ggplot()+
  geom_polygon(data=plotdata, aes(x=long, y=lat, group = group, fill=factor(evd)))+
  geom_polygon(data=plotdata, aes(x=long, y=lat,
                                     group = group), fill=NA, color ="grey10", size = 0.045)+
  theme_minimal() + theme_noline + theme(legend.position='none')+
  scale_fill_manual(breaks = c("0","1"),
                     values=c("grey90", "firebrick4"))+
  labs(title="Electoral violence, 2002-2011")


## electoral fraud
## generates right-hand map from Figure 1

ggplot()+
  geom_polygon(data=plotdata, aes(x=long, y=lat, group = group, fill=factor(efd)))+
  geom_polygon(data=plotdata, aes(x=long, y=lat,
                                  group = group), fill=NA, color ="grey10", size = 0.045)+
  theme_minimal() + theme_noline + theme(legend.position='none')+
  scale_fill_manual(breaks = c("0","1"),
                    values=c("grey90", "royalblue4"))+
  labs(title="Electoral fraud, 2002-2011")




## land concentration
## generates left-hand map from Figure 2

ggplot()+
  geom_polygon(data=plotdata, aes(x=long, y=lat,
                                  group = group, fill=g_prop.mean))+
  geom_polygon(data=plotdata, aes(x=long, y=lat,
                                  group = group), fill=NA, color ="grey10", size = 0.045)+
   theme_minimal() + theme_noline + labs(fill = "Land \nconcentration")+
  scale_fill_distiller(palette = 4, direction = 1, na.value = "grey90", 
                       breaks = pretty_breaks(5))+guides(fill = guide_legend())+
  theme(legend.position = c(0.15, 0.8))


## soil quality
## generates right-hand map from Figure 2

ggplot()+
  geom_polygon(data=plotdata, aes(x=long, y=lat,
                                  group = group, fill=aptitud.mean))+
  geom_polygon(data=plotdata, aes(x=long, y=lat,
                                  group = group), fill=NA, color ="grey10", size = 0.045)+
  theme_minimal() + theme_noline + labs(fill = "Soil \nquality")+
  scale_fill_distiller(palette = 9, direction = 1, na.value = "grey90", 
                       breaks = pretty_breaks(5))+guides(fill = guide_legend())+
  theme(legend.position = c(0.15, 0.8))









#======================================
#          instrument plots           #
#======================================

## histogram for soil quality
## creates Panel A of Figure 3

ggplot(dat, aes(aptitud))+
  geom_histogram(alpha=0.6, binwidth = 0.4)+
  geom_vline(xintercept = mean(dat$aptitud, na.rm=T), linetype="dashed", color="red", size=.6)+
  theme_bw()+xlab("Soil quality") +ylab("Count")+
  theme(axis.text=element_text(size=18), 
        axis.title=element_text(size=22),
        plot.title = element_text(hjust = 0.5, size=22))+
  labs(title = "Panel A. Histogram of soil quality")


##histogram for land concentration
##creates Panel A of Figure 3

ggplot(dat,aes(g_prop, aptitud))+
  geom_point(alpha=0.3, color="grey70", size=2)+
  geom_smooth(formula=y~poly(x,4), method = "lm", color="red", se=F, linetype=2)+
  geom_smooth(formula=y~x, method = "lm", color="skyblue3", se=F)+
  theme_bw()+
  xlab("Land concentration") +ylab("Soil quality")+
  theme(axis.text=element_text(size=18), 
        axis.title=element_text(size=22),
        plot.title = element_text(hjust = 0.5, size=22))+
  labs(title = "Panel B. Scatterplot of land concentration and soil quality")



