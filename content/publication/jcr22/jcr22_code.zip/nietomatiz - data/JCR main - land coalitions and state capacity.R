# required packages - install first
library(estimatr)
library(tidyverse)



###################################################################
###################################################################
#
#   Land and state capacity during civil wars: how land-based
#      coalitions undermine property taxation in Colombia
#
#                    Camilo Nieto-Matiz
#                 camilo.nieto-matiz@utsa.edu
###################################################################
###################################################################
 


# load dataframes
load("land coalition_main analysis.RData") # main analysis - diff-in-diff
load("land coalition_prop rights.RData") # mechanisms 
load("appraisal_palm_nonpalm.RData") # land values

#linear time trends
RLT_<-cbind(data_land$regXano1,data_land$regXano2,data_land$regXano3,data_land$regXano4)



################################################################
#                       Tables  
################################################################
#================================================
#                   Table 1
#          Main results - property taxes
#================================================

summary(m1<-lm_robust(ptax~palmsuit*price+
                   price*altura+
                   price*disbogota+
                   price*area+
                   price*indrural+
                  RLT_,
                  data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(m2<-lm_robust(ptax~palmsuit*price*log(guerrilla+1)+
                        palmsuit*price*log(para+1)+
                        palmsuit*price*(gini+1)+
                        price*altura+
                        price*disbogota+
                        price*area+
                        price*indrural+RLT_,
                      data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(m3<-lm_robust(ptax~palmsuit*price*log(guerrilla+1)+
                        palmsuit*price*log(para+1)+
                        price*altura+
                        price*disbogota+
                        price*area+
                        price*indrural+RLT_,
                      data=data_land, subset= g_med==0,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(m4<-lm_robust(ptax~palmsuit*price*log(guerrilla+1)+
                        palmsuit*price*log(para+1)+
                        price*altura+
                        price*disbogota+
                        price*area+
                        price*indrural+RLT_,
                      data=data_land, subset= g_med==1,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))





#================================================
#                   Table 2
#          Property rights mechanisms
#================================================


### cadastral lag
summary(cat1<-lm_robust(rezago0809~palmsuit*log(guerrilla+1)+
                          palmsuit*log(para+1)+
                          palmsuit*(gini+1)+
                          altura+conflicto+area+popdens,
                        data=data_prop,clusters=coddepto, se_type = "stata"))

summary(cat2<-lm_robust(rezago0809~ palmsuit*log(guerrilla+1)+
                          palmsuit*log(para+1)+
                          palmsuit*(gini+1)+
                          altura+conflicto+area+popdens,
                        data=data_prop,subset=g_med==0,clusters=coddepto, se_type = "stata"))

summary(cat3<-lm_robust(rezago0809~ palmsuit*log(guerrilla+1)+
                          palmsuit*log(para+1)+
                          palmsuit*(gini+1)+
                          altura+conflicto+area+popdens,
                        data=data_prop,subset=g_med==1,clusters=coddepto, se_type = "stata"))


### informality
summary(inf1<-lm_robust(log(inform0809+1)~ palmsuit*log(guerrilla+1)+
                          palmsuit*log(para+1)+
                          palmsuit*(gini+1)+
                          altura+conflicto+area+popdens,
                        data=data_prop,clusters=coddepto, se_type = "stata"))

summary(inf2<-lm_robust(log(inform0809+1)~ palmsuit*log(guerrilla+1)+
                          palmsuit*log(para+1)+
                          palmsuit*(gini+1)+
                          altura+conflicto+area+popdens,
                        data=data_prop,subset=g_med==0,clusters=coddepto, se_type = "stata"))

summary(inf3<-lm_robust(log(inform0809+1)~ palmsuit*log(guerrilla+1)+
                          palmsuit*log(para+1)+
                          palmsuit*(gini+1)+
                          altura+conflicto+area+popdens,
                        data=data_prop,subset=g_med==1,clusters=coddepto, se_type = "stata"))



### cadastral appraisals
summary(val1<-lm_robust(log(appraisal0809+1)~ palmsuit*log(guerrilla+1)+
                          palmsuit*log(para+1)+
                          palmsuit*(gini+1)+
                          altura+conflicto+area+popdens,
                        data=data_prop,clusters=coddepto, se_type = "stata"))

summary(val2<-lm_robust(log(appraisal0809+1)~ palmsuit*log(guerrilla+1)+
                          palmsuit*log(para+1)+
                          palmsuit*(gini+1)+
                          altura+conflicto+area+popdens,
                        data=data_prop,subset=g_med==0,clusters=coddepto, se_type = "stata"))

summary(val3<-lm_robust(log(appraisal0809+1)~ palmsuit*log(guerrilla+1)+
                          palmsuit*log(para+1)+
                          palmsuit*(gini+1)+
                          altura+conflicto+area+popdens,
                        data=data_prop,subset=g_med==1,clusters=coddepto, se_type = "stata"))
 





################################################################
#                      Figures
################################################################

#================================================
#                  Figure 1
#          Event study model - baseline
#================================================

summary(dyn1<-lm_robust(ptax~
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+RLT_+
                          b00+b01+b02+b03+b04+b05+b07+b08+b09+b10+b11+b12+b13+b14,
                        data=data_land,fixed_effects=codmpio~ano,clusters = codmpio, se_type = "stata"))

df_b<-tidy(dyn1)[10:23,2:7] %>%
  rbind(c(0,rep(NA,5))) %>% 
  mutate(year=as.factor(c(2000:2005,2007:2014,2006)))

df_b %>% 
  mutate(year = fct_reorder(year, as.numeric(as.character(year)))) %>%
  ggplot(aes(y = year, x = estimate)) + 
  geom_errorbarh(aes( xmin = conf.low, xmax = conf.high, height = 0.2),
                 color="darkgreen", size=.5) +
  geom_point() + ylab('')+
  theme_bw() + xlab('') + coord_flip() +
  geom_vline(xintercept = 0, colour = gray(1/2), lty = 2)+
  theme(legend.position ="none")





#================================================
#                   Figure 2
#  Effect of paramilitary violence in settings 
#     of low and high land concentration
#================================================


plot1 <- m3 %>% tidy(conf.level = 0.95) %>%  
  filter(term=="palmsuit:price:log(para + 1)") %>%
  dplyr::mutate(term = recode_factor(term, "palmsuit:price:log(para + 1)"= "Low land \nconcentration")) 

plot2 <- m4 %>%  tidy(conf.level = 0.95) %>%
  filter(term=="palmsuit:price:log(para + 1)") %>%
  dplyr::mutate(term = recode_factor(term, "palmsuit:price:log(para + 1)"= "High land \nconcentration"))
plot <- rbind(plot1,plot2)

 plot %>% 
  ggplot(aes(y = term, x = estimate)) + 
  geom_vline(xintercept = 0, linetype = 2, color="red",size=.4) +
  geom_errorbarh(aes(xmin = conf.low, xmax = conf.high, height = 0.06),color="black",size=.5) +
  geom_point() + ylab('') + coord_flip()+ 
  theme_bw()  + xlab('') + xlim(-.04,.04)+
   theme(legend.position ="none")
 




#================================================
#                   Figure 3
#     Land values in palm vs nonpalm areas
#================================================

#load data
land_val %>% 
  ggplot(aes(year,avaluo, group=palmapr, size=factor(palmapr), color=factor(palmapr))) +
  geom_line() + theme_bw() +
  scale_color_manual(values=c("orange", "blue"), labels = c("Non-palm", "Palm")) + 
  scale_size_manual(values = c(.7,1.5), labels = c("Non-palm", "Palm")) +
  geom_vline(xintercept = 8, alpha=.5, color="red", linetype=2) +
  theme(legend.position = "bottom",
        legend.title = element_blank(),
        legend.background = element_rect(fill = "transparent"),
        axis.title.x=element_blank()) +
  xlab('')+ylab('Land value')






 
#================================================
#                   Figure 4.A
#        Vote share for right-wing parties
#================================================


summary(mayor_share1<-lm_robust(share_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                   palmsuit*log(para+1)+
                                   vote_share_trad2003+
                                   altura+conflicto+area+popdens,
                                 data=data_prop,subset=g_med==0,clusters = coddepto, se_type = "stata")) 
summary(mayor_share2<-lm_robust(share_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                   palmsuit*log(para+1)+
                                   vote_share_trad2003+
                                   altura+conflicto+area+popdens,
                                 data=data_prop,subset=g_med==1,clusters = coddepto, se_type = "stata")) 
 
 
summary(council_share1<-lm_robust(share_cc_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                     palmsuit*log(para+1)+
                                     vote_share_trad2003+
                                     altura+conflicto+area+popdens,
                                   data=data_prop,subset=g_med==0,clusters = coddepto, se_type = "stata")) 
summary(council_share2<-lm_robust(share_cc_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                     palmsuit*log(para+1)+
                                     vote_share_trad2003+
                                     altura+conflicto+area+popdens,
                                   data=data_prop,subset=g_med==1,clusters = coddepto, se_type = "stata")) 
 
 
 
 #plot
elec_plot1 <- mayor_share1 %>%  tidy %>%  
   filter(term=="palmsuit:log(para + 1)") %>%
   dplyr::mutate(term = recode_factor(term, "palmsuit:log(para + 1)"= "Low land \nconcentration")) 
elec_plot2 <- mayor_share2 %>%  tidy %>%
   filter(term=="palmsuit:log(para + 1)") %>%
   dplyr::mutate(term = recode_factor(term, "palmsuit:log(para + 1)"= "High land \nconcentration"))
 
elec_plot3 <- council_share1 %>%  tidy %>%  
   filter(term=="palmsuit:log(para + 1)") %>%
   dplyr::mutate(term = recode_factor(term, "palmsuit:log(para + 1)"= "Low land \nconcentration")) 
elec_plot4 <- council_share2 %>%  tidy %>%
   filter(term=="palmsuit:log(para + 1)") %>%
   dplyr::mutate(term = recode_factor(term, "palmsuit:log(para + 1)"= "High land \nconcentration"))
plot_assas <- rbind(elec_plot1,elec_plot2,elec_plot3,elec_plot4)
 
plot_assas %>% 
  ggplot(aes(x = term, y = estimate)) + 
  geom_hline(yintercept = 0, linetype = 2, color="red",size=.4) +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high, color=outcome), 
                 position = position_dodge(width = .15),
                 size=.5, width=.1) +
   geom_point(aes(color=outcome,shape=outcome), 
              position = position_dodge(width = .15))+ 
   ylab('') + theme_bw() + ylim(-.5,.5) + xlab('') +
   scale_shape_discrete(labels = c("Council",  "Mayor"))+
   scale_color_manual(labels = c("Council",  "Mayor"),
                      values = c("black", "blue"))+
   theme(legend.position = c(0.2, .83),
         legend.text = element_text(size=6),
         legend.title = element_blank()) 
 
 
 
 
 
 
 

#================================================
#                   Figure 4.B
#        Assassinations of state officials
#================================================
 
summary(int2<-lm_robust(pol_assassination~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+RLT_,
                        data=data_land, subset= g_med==0,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(int3<-lm_robust(pol_assassination~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+RLT_,
                        data=data_land, subset= g_med==1,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

#plot
intimid_plot1 <- int2 %>%  tidy %>%  
  filter(term=="palmsuit:price:log(para + 1)") %>%
  dplyr::mutate(term = recode_factor(term, "palmsuit:price:log(para + 1)"= "Low land \nconcentration")) 
intimid_plot2 <- int3 %>%  tidy %>%
  filter(term=="palmsuit:price:log(para + 1)") %>%
  dplyr::mutate(term = recode_factor(term, "palmsuit:price:log(para + 1)"= "High land \nconcentration"))
plot_intimid <- rbind(intimid_plot1,intimid_plot2)

plot_intimid %>% 
  ggplot(aes(y = term, x = estimate)) + 
  geom_vline(xintercept = 0, linetype = 2, color="red",size=.4) +
  geom_errorbarh(aes(xmin = conf.low, xmax = conf.high, height = 0.06),color="black",size=.5) +
  geom_point() + ylab('') + coord_flip()+ 
  theme_bw() + xlim(-3,3) + xlab('') +
  theme(legend.position ="none")






