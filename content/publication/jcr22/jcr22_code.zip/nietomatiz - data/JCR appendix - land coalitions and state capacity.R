# required packages - install first
library(sjPlot)
library(estimatr)
library(tidyverse)


###################################################################
###################################################################
#   Land and state capacity during civil wars: how land-based
#      coalitions undermine property taxation in Colombia
#
#                      Camilo Nieto-Matiz
#                  camilo.nieto-matiz@utsa.edu
###################################################################
###################################################################



# load dataframes
load("land coalition_main analysis.RData") # main analysis - diff-in-diff
load("land coalition_prop rights.RData") # mechanisms 

#linear time trends for diff-in-diff
RLT_<-cbind(data_land$regXano1,data_land$regXano2,data_land$regXano3,data_land$regXano4)


################################################################
#         APPENDIX B. Validating the research design
################################################################
#================================================
#                 Appendix B.2
#  Assessing the parallel trends assumption
#================================================


## paramilitaries - low land concentration
summary(dyn2<-lm_robust(ptax ~ 
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+
                          price*log(para+1)+RLT_+
                          p00_p+p01_p+p02_p+p03_p+p04_p+p05_p+p07_p+p08_p+p09_p+p10_p+p11_p+p12_p+p13_p+p14_p,               
                        subset=g_med==0,data=data_land,fixed_effects=codmpio~ano,clusters = codmpio, se_type = "stata"))


dd_low <-tidy(dyn2)[11:24,2:7] %>%
  rbind(c(0,rep(NA,5))) %>% 
  mutate(year=as.factor(c(2000:2005,2007:2014,2006)))

dd_low %>% 
  mutate(year = fct_reorder(year, as.numeric(as.character(year)))) %>%
  ggplot(aes(y = year, x = estimate)) + 
  geom_errorbarh(aes( xmin = conf.low, xmax = conf.high, height = 0.2),
                 color="deeppink3", size=.5) + xlim(-0.001,0.001)+
  geom_point() + ylab('')+
  theme_bw() + xlab('') + coord_flip() + 
  geom_vline(xintercept = 0, colour = gray(1/2), lty = 2)
 



## paramilitaries - high land concentration
summary(dyn3<-lm_robust(ptax ~ 
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+
                          price*log(para+1)+RLT_+
                          p00_p+p01_p+p02_p+p03_p+p04_p+p05_p+p07_p+p08_p+p09_p+p10_p+p11_p+p12_p+p13_p+p14_p,               
                        subset=g_med==1,data=data_land,fixed_effects=codmpio~ano,clusters = codmpio, se_type = "stata"))

dd_high<-tidy(dyn3)[11:24,2:7] %>%
  rbind(c(0,rep(NA,5))) %>% 
  mutate(year=as.factor(c(2000:2005,2007:2014,2006)))

dd_high %>% 
  mutate(year = fct_reorder(year, as.numeric(as.character(year)))) %>%
  ggplot(aes(y = year, x = estimate)) + 
  geom_errorbarh(aes( xmin = conf.low, xmax = conf.high, height = 0.2),
                 color="deeppink3", size=.5) +
  geom_point() + ylab('')+
  theme_bw() + xlab('') + coord_flip() + 
  geom_vline(xintercept = 0, colour = gray(1/2), lty = 2)
 





################################################################
#    APPENDIX C. Robustness checks and placebo outcome 
################################################################
#================================================
#                 Appendix C.1
#  Dropping the insurgency triple-difference
#================================================


# Table C.1: Main results - No insurgency triple interaction, 
#            with covariates

summary(nog1<-lm_robust(ptax~ 
                       palmsuit*price*log(para+1)+
                       palmsuit*price*gini+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(nog2<-lm_robust(ptax~ 
                        palmsuit*price*log(para+1)+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land,subset= g_med==0, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(nog3<-lm_robust(ptax~
                        palmsuit*price*log(para+1)+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land,subset= g_med==1, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))



# Table C.2: Main results - No insurgency triple interaction, 
#            without covariates

summary(nog4<-lm_robust(ptax~ 
                        palmsuit*price*log(para+1)+
                        palmsuit*price*gini+
                        RLT_,
                      data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(nog5<-lm_robust(ptax~ 
                        palmsuit*price*log(para+1)+
                        RLT_,
                      data=data_land,subset= g_med==0, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(nog6<-lm_robust(ptax~
                        palmsuit*price*log(para+1)+
                        RLT_,
                      data=data_land,subset= g_med==1, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))



# Table C.3: Main results - No insurgency triple interaction, 
#            without covariates, dummy violent actor


summary(nog7<-lm_robust(ptax~ 
                        palmsuit*price*ps+
                        palmsuit*price*gini+
                        RLT_,
                      data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(nog8<-lm_robust(ptax~ 
                        palmsuit*price*ps+
                        RLT_,
                      data=data_land,subset= g_med==0, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(nog9<-lm_robust(ptax~
                        palmsuit*price*ps+
                        RLT_,
                      data=data_land,subset= g_med==1, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))








#================================================
#                 Appendix C.2
#   Using dichotomous measure of violent group
#================================================


summary(d1<-lm_robust(ptax~palmsuit*price*gs+
                        palmsuit*price*ps+
                        palmsuit*price*gini+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(d2<-lm_robust(ptax~palmsuit*price*gs+
                        palmsuit*price*ps+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land,subset= g_med==0, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(d3<-lm_robust(ptax~palmsuit*price*gs+
                        palmsuit*price*ps+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land,subset= g_med==1, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))
 







#================================================
#                 Appendix C.3
#   Results using oil palm production data
#================================================


# with controls
summary(prod1<-lm_robust(ptax~log(intenspalma3+1)*price+
                           price*area+
                           price*altura+
                           price*disbogota+
                           price*indrural+
                           RLT_,
                         data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(prod2<-lm_robust(ptax~log(intenspalma3+1)*price*log(guerrilla+1)+
                           log(intenspalma3+1)*price*log(para+1)+
                           log(intenspalma3+1)*price*(gini+1)+
                           price*area+
                           price*altura+
                           price*disbogota+
                           price*indrural+
                           RLT_,
                         data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(prod3<-lm_robust(ptax~log(intenspalma3+1)*price*log(guerrilla+1)+
                           log(intenspalma3+1)*price*log(para+1)+
                           price*area+
                           price*altura+
                           price*disbogota+
                           price*indrural+
                           RLT_,
                         data=data_land, subset= g_med==0,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(prod4<-lm_robust(ptax~log(intenspalma3+1)*price*log(guerrilla+1)+
                           log(intenspalma3+1)*price*log(para+1)+
                           price*area+
                           price*altura+
                           price*disbogota+
                           price*indrural+
                           RLT_,
                         data=data_land, subset= g_med==1,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))



# no controls
summary(prod5<-lm_robust(ptax~log(intenspalma3+1)*price+
                           RLT_,
                         data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(prod6<-lm_robust(ptax~log(intenspalma3+1)*price*log(guerrilla+1)+
                           log(intenspalma3+1)*price*log(para+1)+
                           log(intenspalma3+1)*price*(gini+1)+
                           RLT_,
                         data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(prod7<-lm_robust(ptax~log(intenspalma3+1)*price*log(guerrilla+1)+
                           log(intenspalma3+1)*price*log(para+1)+
                           RLT_,
                         data=data_land, subset= g_med==0,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(prod8<-lm_robust(ptax~log(intenspalma3+1)*price*log(guerrilla+1)+
                           log(intenspalma3+1)*price*log(para+1)+
                           RLT_,
                         data=data_land, subset= g_med==1,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))






#================================================
#                 Appendix C.4
#         Placebo outcome: non-tax revenue
#================================================


summary(nt1<-lm_robust(nontax~palmsuit*price+
                         price*area+
                         price*altura+
                         price*disbogota+
                         price*indrural+RLT_,
                       data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(nt2<-lm_robust(nontax~palmsuit*price*log(guerrilla+1)+
                         palmsuit*price*log(para+1)+
                         palmsuit*price*(gini+1)+
                         price*area+
                         price*altura+
                         price*disbogota+
                         price*indrural+RLT_,
                       data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(nt3<-lm_robust(nontax~palmsuit*price*log(guerrilla+1)+
                         palmsuit*price*log(para+1)+
                         price*area+
                         price*altura+
                         price*disbogota+
                         price*indrural+RLT_,
                       data=data_land, subset= g_med==0,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(nt4<-lm_robust(nontax~palmsuit*price*log(guerrilla+1)+
                         palmsuit*price*log(para+1)+
                         price*area+
                         price*altura+
                         price*disbogota+
                         price*indrural+RLT_,
                       data=data_land, subset= g_med==1,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

 




################################################################
#    APPENDIX D. Testing additional mechanisms and outcomes  
################################################################
#================================================
#                 Appendix D.1
#  Effect of the palm shock on forced displacement
#================================================

summary(dis1<-lm_robust(int_desp~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          palmsuit*price*(gini+1)+
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+
                          RLT_,
                        data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(dis2<-lm_robust(int_desp~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+RLT_,
                        data=data_land, subset= g_med==0,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(dis3<-lm_robust(int_desp~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+RLT_,
                        data=data_land, subset= g_med==1,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))




#================================================
#                 Appendix D.2
#    Effect of the palm shock on homicide rates
#================================================

summary(hom1<-lm_robust(homrate~palmsuit*price+
                          price*area+
                          price*altura+
                          price*disbogota+
                          price*indrural+RLT_,
                        data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(hom2<-lm_robust(homrate~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          palmsuit*price*(gini+1)+
                          price*area+
                          price*altura+
                          price*disbogota+
                          price*indrural+RLT_,
                        data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(hom3<-lm_robust(homrate~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          price*area+
                          price*altura+
                          price*disbogota+
                          price*indrural+RLT_,
                        data=data_land, subset= g_med==0,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(hom4<-lm_robust(homrate~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          price*area+
                          price*altura+
                          price*disbogota+
                          price*indrural+RLT_,
                        data=data_land, subset= g_med==1,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

 



#================================================
#                 Appendix D.3
#   Marginal fx palm suitability - paramilitaries
#================================================

##cadastral lag
summary(me1<-lm_robust(rezago0809~palmsuit*para_log+
                         palmsuit*log(guerrilla+1),
                       data=data_prop, subset=g_med==0,clusters = coddepto, se_type = "stata"))
plot_model(me1, type = "pred", terms = c("para_log", "palmsuit [1.099,2.303]"))+
  theme_bw()+xlab('Paramilitary violence')+ylab('Cadaster lag')+
  theme(plot.title = element_blank())+
  scale_color_discrete(name = "Palm \nsuitability", labels = c("Lowest", "Highest"))


summary(me2<-lm_robust(rezago0809~palmsuit*para_log+
                         palmsuit*log(guerrilla+1),
                       data=data_prop, subset=g_med==1,clusters = coddepto, se_type = "stata"))
plot_model(me2, type = "pred", terms = c("para_log", "palmsuit [1.099,2.303]"))+
  theme_bw()+xlab('Paramilitary violence')+ylab('Cadaster lag')+
  theme(plot.title = element_blank())+
  scale_color_discrete(name = "Palm \nsuitability", labels = c("Lowest", "Highest"))



##land value
summary(me3<-lm_robust(log(appraisal0809+1)~palmsuit*para_log+
                         palmsuit*log(guerrilla+1),
                       data=data_prop, subset=g_med==0,clusters = coddepto, se_type = "stata"))
plot_model(me3, type = "pred", terms = c("para_log", "palmsuit [1.099,2.303]"))+
  theme_bw()+xlab('Paramilitary violence')+ylab('Land value')+
  theme(plot.title = element_blank())+
  scale_color_discrete(name = "Palm \nsuitability", labels = c("Lowest", "Highest"))

summary(me4<-lm_robust(log(appraisal0809+1)~palmsuit*para_log+
                         palmsuit*log(guerrilla+1),
                       data=data_prop, subset=g_med==1,clusters = coddepto, se_type = "stata"))
plot_model(me4, type = "pred", terms = c("para_log", "palmsuit [1.099,2.303]"))+
  theme_bw()+xlab('Paramilitary violence')+ylab('Land value')+
  theme(plot.title = element_blank())+
  scale_color_discrete(name = "Palm \nsuitability", labels = c("Lowest", "Highest"))
 

##land informality
summary(me5<-lm_robust(log(inform0809+1)~palmsuit*para_log+
                         palmsuit*log(guerrilla+1),
                       data=data_prop, subset=g_med==0,clusters = coddepto, se_type = "stata"))
plot_model(me5, type = "pred", terms = c("para_log", "palmsuit [1.099,2.303]"))+
  theme_bw()+xlab('Paramilitary violence')+ylab('Land informality')+
  theme(plot.title = element_blank())+
  scale_color_discrete(name = "Palm \nsuitability", labels = c("Lowest", "Highest"))

summary(me6<-lm_robust(log(inform0809+1)~palmsuit*para_log+
                         palmsuit*log(guerrilla+1),
                       data=data_prop, subset=g_med==1,clusters = coddepto, se_type = "stata"))
plot_model(me6, type = "pred", terms = c("para_log", "palmsuit [1.099,2.303]"))+
  theme_bw()+xlab('Paramilitary violence')+ylab('Land informality')+
  theme(plot.title = element_blank())+
  scale_color_discrete(name = "Palm \nsuitability", labels = c("Lowest", "Highest"))








#================================================
#                 Appendix D.4
#   Relationship btw palm suitability and land values
#================================================

summary(op_lv1<-lm_robust(log(appraisal0809+1)~palmsuit+altura+conflicto+
                            area+popdens+Violencia_48_a_53,
                          data=data_prop,clusters = data_prop$coddepto, se_type = "stata"))
summary(op_lv2<-lm_robust(log(appraisal0809+1)~palmsuit+altura+conflicto+
                            area+popdens+Violencia_48_a_53,
                          data=data_prop,subset=g_med==0,clusters = data_prop$coddepto, se_type = "stata"))
summary(op_lv3<-lm_robust(log(appraisal0809+1)~palmsuit+altura+conflicto+
                            area+popdens+Violencia_48_a_53,
                          data=data_prop,subset=g_med==1,clusters = data_prop$coddepto, se_type = "stata"))

data_prop %>% 
  ggplot(aes(x=(palmsuit), y=log(appraisal0809+1)))+geom_point(alpha=.3) +
  geom_smooth() + theme_bw() + 
  xlab('Oil palm suitability') + ylab('Land value (08-09)')







#================================================
#                 Appendix D.5
#   The palm shock and changes in economic activity
#================================================


summary(l1<-lm_robust(log(light_mean+1)~palmsuit*price+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(l2<-lm_robust(log(light_mean+1)~palmsuit*price*log(guerrilla+1)+
                        palmsuit*price*log(para+1)+
                        palmsuit*price*(gini+1)+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))


summary(l3<-lm_robust(log(light_mean+1)~palmsuit*price*log(guerrilla+1)+
                        palmsuit*price*log(para+1)+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land, subset=g_med==0,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(l4<-lm_robust(log(light_mean+1)~palmsuit*price*log(guerrilla+1)+
                        palmsuit*price*log(para+1)+
                        price*area+
                        price*altura+
                        price*disbogota+
                        price*indrural+RLT_,
                      data=data_land, subset=g_med==1,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))




#================================================
#                 Appendix D.6
# Government capture: changes in electoral outcomes
#================================================

### low land concentration
summary(mayor_dummy1<-lm_robust(won_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                  palmsuit*log(para+1)+
                                  vote_share_trad2003+
                                  altura+conflicto+area+popdens,
                                data=data_prop,subset=g_med==0,clusters = coddepto, se_type = "stata")) 

summary(mayor_share1<-lm_robust(share_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                  palmsuit*log(para+1)+
                                  vote_share_trad2003+
                                  altura+conflicto+area+popdens,
                                data=data_prop,subset=g_med==0,clusters = coddepto, se_type = "stata")) 

summary(council_share1<-lm_robust(share_cc_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                    palmsuit*log(para+1)+
                                    vote_share_trad2003+
                                    altura+conflicto+area+popdens,
                                  data=data_prop,subset=g_med==0,clusters = coddepto, se_type = "stata")) 

### high land concentration
summary(mayor_dummy2<-lm_robust(won_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                  palmsuit*log(para+1)+
                                  vote_share_trad2003+
                                  altura+conflicto+area+popdens,
                                data=data_prop,subset=g_med==1,clusters = coddepto, se_type = "stata")) 

summary(mayor_share2<-lm_robust(share_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                  palmsuit*log(para+1)+
                                  vote_share_trad2003+
                                  altura+conflicto+area+popdens,
                                data=data_prop,subset=g_med==1,clusters = coddepto, se_type = "stata")) 

summary(council_share2<-lm_robust(share_cc_uribe_conservador11_12~palmsuit*log(guerrilla+1)+
                                    palmsuit*log(para+1)+
                                    vote_share_trad2003+
                                    altura+conflicto+area+popdens,
                                  data=data_prop,subset=g_med==1,clusters = coddepto, se_type = "stata")) 






#================================================
#                 Appendix D.7
# Intimidation: selective assassinations of state officials
#================================================


summary(int0<-lm_robust(pol_assassination~palmsuit*price+
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+RLT_,
                        data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(int1<-lm_robust(pol_assassination~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          palmsuit*price*(gini+1)+
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+RLT_,
                        data=data_land, clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(int2<-lm_robust(pol_assassination~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+RLT_,
                        data=data_land, subset= g_med==0,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))

summary(int3<-lm_robust(pol_assassination~palmsuit*price*log(guerrilla+1)+
                          palmsuit*price*log(para+1)+
                          price*altura+
                          price*disbogota+
                          price*area+
                          price*indrural+RLT_,
                        data=data_land, subset= g_med==1,clusters = codmpio, fixed_effects=codmpio~ano, se_type = "stata"))







 











 

 
