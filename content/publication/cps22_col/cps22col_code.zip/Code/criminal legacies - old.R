rm(list=ls(all=T))

library(foreign)
library(DataCombine)
require(dplyr) #group_by
require(plyr) #ddply
library(readstata13)
library(rdrobust)
library(rdd)
library(ggplot2)
library(rddensity)
library(rdlocrand)

# set working dir
setwd("~/Box Sync/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/")

# get data
data <- read.dta13("RD_data.dta")


summary(rdrobust((data_wide$guerrilla+1),dat$mv,c=0,p=1,
                 covs = NULL,all = T,vce = "hc0", kernel="tri"))

#============================= 
#   create covariate frames
#=============================

# covariate dataframes
covs1<-cbind(data_wide$altura, data_wide$areaoficialkm2, data_wide$discapital)

covs2<-cbind(dat$altura, dat$areaoficialkm2, dat$g_terreno,
             dat$coca, dat$discapital, dat$desemp_fisc)


#===============================================
#      basic rd estimates - linear polynomial
#===============================================

#---------------
#   homicides 
#---------------
dv.h <- dat[, c("homrate_2008","homrate_2009","homrate_2010","homrate_2011",
              "homrate_2012","homrate_2013","homrate_2014", "h1", "h2")]

hom.est<-lapply(1:ncol(dv.h), function(x)summary(rdrobust(dv.h[,x], dat$mv,
                                                       c = 0, p=1, vce = "hc0",
                                                       bwselect = "mserd", kernel="tri", 
                                                       covs=NULL, all = T)))
#---------------
#    taxes 
#---------------

dv.t <- dat[, c("ptax.2008","ptax.2009","ptax.2010","ptax.2011",
              "ptax.2012","ptax.2013","ptax.2014","proptax1l","proptax2l")]

tax.est <-lapply(1:ncol(dv.t), function(x)summary(rdrobust(dv.t[,x], dat$mv,
                                                        c = 0, p=1, vce = "hc0",
                                                        bwselect = "mserd", kernel="tri", 
                           
 
#===============================================
#      basic rd estimates - quadratic polynomial
#===============================================

#---------------
#   homicides 
#---------------
dv.h <- dat[, c("homrate.2008","homrate.2009","homrate.2010","homrate.2011",
              "homrate.2012","homrate.2013","homrate.2014", "h1", "h2")]

hom.quad<-lapply(1:ncol(dv.h), function(x)summary(rdrobust(dv.h[,x], dat$mv,
                                                        c = 0, p=2, vce = "hc0",
                                                        bwselect = "mserd", kernel="tri", 
                                                        covs=NULL, all = T)))
#---------------
#    taxes 
#---------------

dv.t <- dat[, c("ptax.2008","ptax.2009","ptax.2010","ptax.2011",
              "ptax.2012","ptax.2013","ptax.2014","proptax1l","proptax2l")]

tax.quad<-lapply(1:ncol(dv.t), function(x)summary(rdrobust(dv.t[,x], dat$mv,
                                               c = 0, p=1, vce = "hc0",
                                               bwselect = "mserd", kernel="tri", 
                                               covs=NULL, all = T)))


#===========================================
#  rd estimates with covariate adjustment
#===========================================


#---------------
#   homicides 
#---------------
dv.h <- dat[, c("homrate.2008","homrate.2009","homrate.2010","homrate.2011",
              "homrate.2012","homrate.2013","homrate.2014", "h1", "h2")]

hom.covs<-lapply(1:ncol(dv.h), function(x)summary(rdrobust(dv.h[,x], dat$mv,
                                                        c = 0, p=1, vce = "hc0",
                                                        bwselect = "mserd", kernel="tri", 
                                                        covs=covs1, all = T)))
#---------------
#    taxes 
#---------------

dv.t <- dat[, c("ptax.2008","ptax.2009","ptax.2010","ptax.2011",
              "ptax.2012","ptax.2013","ptax.2014","proptax1l","proptax2l")]

tax.covs<-lapply(1:ncol(dv.t), function(x)summary(rdrobust(dv.t[,x], dat$mv,
                                               c = 0, p=1, vce = "hc0",
                                               bwselect = "mserd", kernel="tri", 
                                               covs=covs1, all = T)))










#============================= 
#       rd plots
#=============================

#------------------------------
#   homicides 08-11 / 08-14
#------------------------------

 
png("hom and tax.png", width = 10, height = 10, units = 'in', res = 300)
par(mfrow=c(2,2))
rdplot(y = dat$h1, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-25, 25), y.lim = c(10,70), covs=NULL, title = "",
       x.label = "Vote margin in 2007", y.label = "Homicide rates 08-11");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$h2, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-25, 25), y.lim = c(10,70), covs=NULL, title = "",
       x.label = "Vote margin in 2007", y.label = "Homicide rates 08-14");abline(v=0, lwd=2, col='red')

#-------------------------
#   taxes 08-11 / 08-14
#-------------------------

rdplot(y = dat$proptax1l, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-25, 25), y.lim = c(3,10), covs=NULL, title = "",
       x.label = "Vote margin in 2007", y.label = "Property taxes 08-11");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$proptax2l, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-25, 25), y.lim = c(3,10), covs=NULL, title = "",
       x.label = "Vote margin in 2007", y.label = "Property taxes 08-14");abline(v=0, lwd=2, col='red')
dev.off()
#----------------------------


#-------------------------
#   taxes 08-14
#-------------------------
png("hom and tax - all.png", width = 10, height = 5, units = 'in', res = 300)
par(mfrow=c(1,2))
rdplot(y = dat$h2, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-25, 25), y.lim = c(10,70), covs=NULL, title = "",
       x.label = "Vote margin in 2007", y.label = "Homicide rates 08-14");abline(v=0, lwd=2, col='red')
rdplot(y = dat$proptax2l, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-25, 25), y.lim = c(3,10), covs=NULL, title = "",
       x.label = "Vote margin in 2007", y.label = "Property taxes 08-14");abline(v=0, lwd=2, col='red')
dev.off()

#-------------------------
#   homicides by year
#-------------------------

png("hom by year.png", width = 7, height = 6, units = 'in', res = 300)
par(mfrow=c(3,3), mai = c(0.3, 0.3, 0.3, 0.3))
rdplot(y = dat$homrate.2008, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25,.25), y.lim = c(10,90), covs=NULL, title = "2008",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$homrate.2009, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(10,90), covs=NULL, title = "2009",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$homrate.2010, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(10,90), covs=NULL, title = "2010",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$homrate.2011, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(10,90), covs=NULL, title = "2011",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$homrate.2012, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(10,90), covs=NULL, title = "2012",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$homrate.2013, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(10,90), covs=NULL, title = "2013",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$homrate.2014, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(10,90), covs=NULL, title = "2014",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
dev.off()


#-------------------------
#    taxes by year
#-------------------------

png("tx by year.png", width = 7, height = 6, units = 'in', res = 300)
par(mfrow=c(3,3), mai = c(0.3, 0.3, 0.3, 0.3))
rdplot(y = dat$ptax.2008, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25,.25), y.lim = c(3,10), covs=NULL, title = "2008",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$ptax.2009, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(3,10), covs=NULL, title = "2009",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$ptax.2010, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(3,10), covs=NULL, title = "2010",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$ptax.2011, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(3,10), covs=NULL, title = "2011",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$ptax.2012, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(3,10), covs=NULL, title = "2012",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$ptax.2013, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(3,10), covs=NULL, title = "2013",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
rdplot(y = dat$ptax.2014, x = dat$mv, c = 0, p=4, binselect = "qsmv",
       x.lim = c(-.25, .25), y.lim = c(3,10), covs=NULL, title = "2014",
       x.label = "", y.label = "");abline(v=0, lwd=2, col='red');abline(v=0, lwd=2, col='red')
dev.off()




#-------------------------
#    estimates over time
#-------------------------

#intervals
interval2 <- -qnorm((1-0.95)/2)  # 95% multiplier
interval1 <- -qnorm((1-0.9)/2)  # 90% multiplier


# homicide frame
hom.est<-lapply(1:ncol(dv.h[1:7]), function(x)rdrobust(dv.h[,x], dat$mv,
                                                          c = 0, p=1, vce = "hc0",
                                                          bwselect = "mserd", kernel="tri", 
                                                          covs=NULL, all = T))
hom.frame<-data.frame(t(round(sapply(hom.est, function(x)cbind(x$coef[3], x$se[3])), 3)))
colnames(hom.frame)[1:2]<-c("Coefficient","SE")
hom.frame$year <-c("2008","2009","2010","2011",
                   "2012","2013","2014")


# taxes frame
tax.est<-lapply(1:ncol(dv.h[1:7]), function(x)rdrobust(dv.t[,x], dat$mv,
                                                       c = 0, p=1, vce = "hc0",
                                                       bwselect = "mserd", kernel="tri", 
                                                       covs=NULL, all = T))
tax.frame<-data.frame(t(round(sapply(tax.est, function(x)cbind(x$coef[3], x$se[3])), 3)))
colnames(tax.frame)[1:2]<-c("Coefficient","SE")
tax.frame$year <-c("2008","2009","2010","2011",
                   "2012","2013","2014")




# homicide plot
ggplot(hom.frame)+ 
  geom_linerange(aes(x = year, ymin = Coefficient - SE*interval1,
                     ymax = Coefficient + SE*interval1),
                 lwd = 2, position = position_dodge(width = 1/2), alpha=0.5)+ 
  geom_linerange(aes(x = year, ymin = Coefficient - SE*interval2,
                     ymax = Coefficient + SE*interval2),
                 lwd = 1, position = position_dodge(width = 1/2), alpha=0.5)+ 
  geom_pointrange(aes(x = year, y = Coefficient, ymin = Coefficient - SE*interval1,
                      ymax = Coefficient + SE*interval1), 
                  lwd = 1/2, position = position_dodge(width = 0.5),
                  shape = 21, fill = "WHITE")+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+theme_bw()+
  geom_vline(xintercept = 4, colour = "red", lty = 1, lwd=0.3)+
  ylim(-90,90)+ggtitle('Homicide rates')+
  ylab('RD estimates')+xlab('')+
  theme(plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(angle = 45, hjust = 1))


# tax plot
txplot <- ggplot(tax.frame)+ 
  geom_linerange(aes(x = year, ymin = Coefficient - SE*interval1,
                     ymax = Coefficient + SE*interval1),
                 lwd = 2, position = position_dodge(width = 1/2), alpha=0.5)+ 
  geom_linerange(aes(x = year, ymin = Coefficient - SE*interval2,
                     ymax = Coefficient + SE*interval2),
                 lwd = 1, position = position_dodge(width = 1/2), alpha=0.5)+ 
  geom_pointrange(aes(x = year, y = Coefficient, ymin = Coefficient - SE*interval1,
                      ymax = Coefficient + SE*interval1), 
                  lwd = 1/2, position = position_dodge(width = 0.5),
                  shape = 21, fill = "WHITE")+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+theme_bw()+
  geom_vline(xintercept = 4, colour = "red", lty = 1, lwd=0.3)+
  ylim(-20,20)+ggtitle('Property taxes')+
  ylab('RD estimates')+xlab('')+
  theme(plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(angle = 45, hjust = 1))

png("dynamic fx.png", width = 8, height = 4, units = 'in', res = 300)
grid.arrange(homplot, txplot, nrow = 1)
dev.off()




 


#============================= 
#    plot
#=============================
png("~/Box Sync/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/mv_hist.png" , units="in", width=5, height=4, res=200)
ggplot(data_wide1, aes(share1))+
  geom_histogram(bins=30, alpha=.7)+
  geom_vline(xintercept = 0, color="red", size=.2)+
  labs(x="Vote margin", y="")+theme_bw()
dev.off()



#============================= 
#     manipulation test
#=============================

rdd <- rddensity(X = dat_new$mv, all = T, fitselect = "unrestricted", 
                 vce="jackknife");summary(rdd)

png("density test.png", width = 5, height = 4, units = 'in', res = 300)
rdplotdensity(rdd, dat_new$mv)
dev.off()

 

#============================= 
#    covariate balance 
#=============================

# local linear specification
summary(bt1<-rdrobust(y = data_wide$altura, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                      kernel="tri",covs=NULL, all = T))
summary(bt2<-rdrobust(y = data_wide$areaoficialkm2, x = data_wide$mv, c = 0, p=1, vce = "nn",
                      kernel="tri", covs=NULL, all = T))
summary(bt3<-rdrobust(y = data_wide$discapital, x = data_wide$mv, c = 0, p=1, vce = "nn",
                      kernel="tri",covs=NULL, all = T))
summary(bt4<-rdrobust(y = data_wide$dismdo, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                      kernel="tri",covs=NULL, all = T))
summary(bt5<-rdrobust(y = log(data_wide$pib_percapita+1), x = data_wide$mv, c = 0, p=1, vce = "nn", 
                     kernel="tri", covs=NULL, all = T))
summary(bt6<-rdrobust(y = data_wide$popdens, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt7<-rdrobust(y = data_wide$aptitud, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt8<-rdrobust(y = data_wide$paras, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt9<-rdrobust(y = data_wide$guerrilla, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt10<-rdrobust(y = data_wide$criminal, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt11<-rdrobust(y = data_wide$conflicto, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt12<-rdrobust(y = data_wide$Violencia_48_a_53, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt13<-rdrobust(y = data_wide$coca, x = data_wide$mv, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt14<-rdrobust(y = log(data_wide$y_transf_nal+1), x = data_wide$mv, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt15<-rdrobust(y = log(data_wide$tx_0407+1), x = data_wide$mv, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt16<-rdrobust(y = log(data_wide$h_0407+1), x = data_wide$mv, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))


#ols - full sample
summary(bt1.full<-lm_robust(altura~mv*treat, data=data_wide))
summary(bt2.full<-lm_robust(areaoficialkm2~mv*treat, data=data_wide))
summary(bt3.full<-lm_robust(discapital~mv*treat, data=data_wide))
summary(bt4.full<-lm_robust(dismdo~mv*treat, data=data_wide))
summary(bt5.full<-lm_robust(log(data_wide$pib_percapita+1)~mv*treat, data=data_wide))
summary(bt6.full<-lm_robust(popdens~mv*treat, data=data_wide))
summary(bt7.full<-lm_robust(aptitud~mv, data=data_wide))
summary(bt8.full<-lm_robust(paras~mv*treat, data=data_wide))
summary(bt9.full<-lm_robust(guerrilla~mv*treat, data=data_wide))
summary(bt10.full<-lm_robust(criminal~mv*treat, data=data_wide))
summary(bt11.full<-lm_robust(conflicto~mv*treat, data=data_wide))
summary(bt12.full<-lm_robust(Violencia_48_a_53~mv*treat, data=data_wide))
summary(bt13.full<-lm_robust(coca~mv*treat, data=data_wide))
summary(bt14.full<-lm_robust(log(data_wide$y_transf_nal+1)~mv*treat, data=data_wide))
summary(bt15.full<-lm_robust(log(data_wide$tx_0407+1)~mv*treat, data=data_wide, fix))
summary(bt16.full<-lm_robust(log(data_wide$h_0407+1)~mv*treat, data=data_wide))




# frame
#frame
balance <- data.frame(Var =    c('Altitude','Area km2', 'Distance to Bogota','Distance to market',
                                 'Per capita GDP','Population','Soil quality','Paramilitary actions',
                                 'Guerrilla actions','Criminal actions','Land conflicts 1901-31', 
                                 'Violence 1948-43','Coca', 'National transfers', 'Property taxes, 04-07', 'Homicide rates, 04-07'),
                  Estimate =   c(bt1$coef[3],bt2$coef[3],bt3$coef[3],bt4$coef[3],bt5$coef[3],bt6$coef[3],bt7$coef[3],
                                 bt8$coef[3],bt9$coef[3],bt10$coef[3],bt11$coef[3],bt12$coef[3],bt13$coef[3],
                                 bt14$coef[3],bt15$coef[3],bt16$coef[3]),
                    pvalue =   c(bt1$pv[3],bt2$pv[3],bt3$pv[3],bt4$pv[3],bt5$pv[3],bt6$pv[3],bt7$pv[3],
                                 bt8$pv[3],bt9$pv[3],bt10$pv[3],bt11$pv[3],bt12$pv[3],bt13$pv[3],
                                 bt14$pv[3],bt15$pv[3],bt16$pv[3]),
                         SE =  c(bt1$se[3],bt2$se[3],bt3$se[3],bt4$se[3],bt5$se[3],bt6$se[3],bt7$se[3],
                                 bt8$se[3],bt9$se[3],bt10$se[3],bt11$se[3],bt12$se[3],bt13$se[3],
                                 bt14$se[3], bt15$se[3], bt16$se[3]))

balance$Var <- factor(balance$Var, ordered(balance$Var))
balance$Specification <- "Local"


balance1 <- data.frame(Var =    c('Altitude','Area km2', 'Distance to Bogota','Distance to market',
                                 'Per capita GDP','Population','Soil quality','Paramilitary actions',
                                 'Guerrilla actions','Criminal actions','Land conflicts 1901-31', 
                                 'Violence 1948-43','Coca', 'National transfers', 'Property taxes, 04-07', 'Homicide rates, 04-07'),
                    Estimate =  c(bt1.full$coefficients[3],bt2.full$coefficients[3],bt3.full$coefficients[3],bt4.full$coefficients[3],bt5.full$coefficients[3],bt6.full$coefficients[3],bt7.full$coefficients[3],
                                  bt8.full$coefficients[3],bt9.full$coefficients[3],bt10.full$coefficients[3],bt11.full$coefficients[3],bt12.full$coefficients[3],bt13.full$coefficients[3],
                                  bt14.full$coefficients[3],bt15.full$coefficients[3],bt16.full$coefficients[3]),
                      pvalue =   c(bt1.full$p.value[3],bt2.full$p.value[3],bt3.full$p.value[3],bt4.full$p.value[3],bt5.full$p.value[3],bt6.full$p.value[3],bt7.full$p.value[3],
                                  bt8.full$p.value[3],bt9.full$p.value[3],bt10.full$p.value[3],bt11.full$p.value[3],bt12.full$p.value[3],bt13.full$p.value[3],
                                  bt14.full$p.value[3],bt15.full$p.value[3],bt16.full$p.value[3]),
                          SE =   c(bt1.full$std.error[3],bt2.full$std.error[3],bt3.full$std.error[3],bt4.full$std.error[3],bt5.full$std.error[3],bt6.full$std.error[3],bt7.full$std.error[3],
                                  bt8.full$std.error[3],bt9.full$std.error[3],bt10.full$std.error[3],bt11.full$std.error[3],bt12.full$std.error[3],bt13.full$std.error[3],
                                  bt14.full$std.error[3],bt15.full$std.error[3],bt16.full$std.error[3]))

balance1$Var <- factor(balance1$Var, ordered(balance$Var))
balance1$Specification <- "Full"

balance.data <- rbind(balance,balance1)
                          
             
# balance plot
png("balance test.png", width = 5, height = 5, units = 'in', res = 400)
ggplot(balance.data)+ 
  geom_point(aes(x = pvalue, y=Var, color=Specification, shape=Specification), 
             lwd = 2, position = position_dodge(width = 0.5))+
  geom_vline(xintercept = 0.05, colour = "red", lty = 2, lwd=0.3)+
  scale_color_manual(values=c("#E69F00", "springgreen4"))+
  xlim(0,1)+
  ylab('')+xlab('p-value')+theme_bw()+
  theme(plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(hjust = 0),
        axis.text.y = element_text(hjust = 0),
        legend.position="bottom")
dev.off()


 
# histogram forcing var
ggplot(data_wide1, aes(share1))+
  geom_histogram(bins=40, alpha=.8)+theme_bw()+
  geom_vline(xintercept = 0, color="red", size=.3)

#----------------------------------------------------------------------------------#
#============================= 
#      cutoff placebo 
#=============================
theme_noline <- theme(axis.text.x = element_blank(),
                      axis.text.y = element_blank(),
                      axis.ticks = element_blank(),
                      axis.title.x=element_blank(),
                      axis.title.y=element_blank(),
                      legend.title= element_text(size = 15),
                      plot.title = element_text(hjust = 0.5),
                      panel.grid.major = element_blank(),
                      panel.grid.minor = element_blank())

cutoff <- c(-.1,-.08,-.06,-.04,-.02, 0, .02,.04,.06,.08,.1)


# matrix to store homicide estimates
store.h <- as.data.frame(matrix(NA,11,3))
colnames(store.h)<-c('coef','se','pv')

# matrix to store taxes estimates
store.t <- as.data.frame(matrix(NA,11,3))
colnames(store.t)<-c('coef','se','pv')

# Initiate loop for homicides #
for (i in 1:length(cutoff)) {
  # Estimate model
  summary(hom_loop <- rdrobust((data_wide$h_0814+1), x = data_wide$mv, c = cutoff[i], p=1, vce = "nn", 
                          bwselect = "mserd", kernel="tri", covs=NULL, all = T))
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store.h[[i,1]] <- hom_loop$coef[3]
  store.h[[i,2]] <- hom_loop$se[3]
  store.h[[i,3]] <- hom_loop$pv[3]
  store.h$c <- cutoff

 # Initiate loop for taxes #
  for (i in 1:length(cutoff)) {
    # Estimate model
    summary(tx_loop <- rdrobust((data_wide$tx_0815+1), x = data_wide$mv, c = cutoff[i], p=1, vce = "nn", 
                                bwselect = "mserd", kernel="tri", covs=NULL, all = T))
    # Extract 3rd row of rd_out() LC function (robust RDD estimate)
    # Place into loop holder
    store.t[[i,1]] <- tx_loop$coef[3]
    store.t[[i,2]] <- tx_loop$se[3]
    store.t[[i,3]] <- tx_loop$pv[3]
    store.t$c <- cutoff
  }  
  
}


# cutoff placebo plot
png("cutoff_pl_hom.png", width = 6, height = 4, units = 'in', res = 300)
ggplot(store.h)+ 
  geom_linerange(aes(x = factor(c), ymin = coef - se*interval2,
                     ymax = coef + se*interval2), color="darkorange1",
                 lwd = 1.5)+ 
  geom_linerange(aes(x = factor(c), ymin = coef - se*interval1,
                     ymax = coef + se*interval1), color="darkorange1",
                 lwd = 2)+ 
  geom_pointrange(aes(x = factor(c), y = coef, ymin = coef - se*interval2,
                      ymax = coef + se*interval2), color="darkorange1",
                  lwd = 0.7, position = position_dodge(width = 0.5),
                  shape = 20, fill = "WHITE")+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+theme_bw()+
  geom_vline(xintercept = 6, colour = "red", lty = 1, lwd=0.3, alpha=0.4)+
  ylim(-90,90)+
  xlab('Placebo cutoffs')+ylab('Estimates')+
  theme(plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid.minor = element_blank())
dev.off()

# cutoff placebo plot
png("cutoff_pl_tax.png", width = 6, height = 4, units = 'in', res = 300)
ggplot(store.t)+ 
  geom_linerange(aes(x = factor(c), ymin = coef - se*interval2,
                     ymax = coef + se*interval2), color="springgreen4",
                 lwd = 1.5)+ 
  geom_linerange(aes(x = factor(c), ymin = coef - se*interval1,
                     ymax = coef + se*interval1), color="springgreen4",
                 lwd = 2)+ 
  geom_pointrange(aes(x = factor(c), y = coef, ymin = coef - se*interval2,
                      ymax = coef + se*interval2), color="springgreen4",
                  lwd = 0.7, position = position_dodge(width = 0.5),
                  shape = 20, fill = "WHITE")+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+theme_bw()+
  geom_vline(xintercept = 6, colour = "red", lty = 1, lwd=0.3, alpha=.4)+
  xlab('Placebo cutoffs')+ylab('Estimates')+
  theme(plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid.minor = element_blank())
dev.off()
 
#----------------------------------------------------------------------------------#


 