rm(list=ls(all=T))



 
 
require(dplyr) #group_by
require(plyr) #ddply
library(readstata13)
library(rdrobust)
library(rdd)
library(reshape)
library(tidyverse)
library(lubridate)
library(fastDummies)
library(naniar)



setwd("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/")
alc07<-read.dta13("2007_Alcaldia.dta") 

#====================================
#    paramilitary-friendly parties
#====================================

# set working dir - treatment
setwd("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/")
alc07<-read.dta13("2007_Alcaldia.dta") %>%
  filter(!is.na(codigo_partido)) %>% #get rid of nulls and blanks
  dplyr::select(codmpio,codigo_partido,votos) 

# create treatment FOR 2007 - # 2 - sin polo 
alc07<-alc07%>%
  
  
  # calculate vote share
  group_by(codmpio) %>%
  dplyr::mutate(prop=votos/sum(votos)) %>% 
  dummy_cols(select_columns = 'codigo_partido') 


# extract 1st and 2nd largest value
elect2007_1 <- alc07 %>%
  group_by(codmpio) %>%
  arrange(desc(prop)) %>%
  slice(1)
elect2007_2 <- alc07 %>%
  group_by(codmpio) %>%
  arrange(desc(prop)) %>%
  slice(2)
#e071<-subset(e071, prop<99)


# rename columns
colnames(elect2007_1) <- paste(colnames(elect2007_1), "1", sep = "_")
colnames(elect2007_2) <- paste(colnames(elect2007_2), "2", sep = "_")

# merge
dat_new <- right_join(elect2007_1,elect2007_2, by=c("codmpio_1"="codmpio_2")) %>%
  
  
  # margin
  transform(mv=prop_1-prop_2) %>%
  dplyr::rename(codmpio=codmpio_1) %>% mutate(codmpio = as.numeric(codmpio)) 


#==============================
#       covariate data
#==============================

# set working dir - covariates
setwd("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/CEDE Panel")

# import covariates
gen<-read.dta13("PANEL_CARACTERISTICAS_GENERALES.dta", convert.dates = F) 
con<-read.dta13("PANEL_CONFLICTO_Y_VIOLENCIA.dta", convert.dates = F)
gob <- read.dta13("PANEL_BUEN_GOBIERNOnuevo13.dta", convert.dates = F)  %>%
  filter(ano>=2000&ano<2016)
agr<-read.dta13("PANEL_AGRICULTURA_Y_TIERRA.dta", convert.dates = F) 
 

# merge frames and select variables
covars <- right_join(gen, con, by=c('codmpio', 'ano')) %>%
  left_join(gob, by=c('codmpio', 'ano')) %>% 
  left_join(agr, by=c('codmpio', 'ano')) %>%
  filter(ano==2005) %>%
  mutate(homrates=homicidios/pobl_tot*100000) %>%
  dplyr::select(codmpio, municipio, coddepto, provincia, pobl_tot, areaoficialkm2, pib_percapita, y_transf_nal,
         indrural, altura, discapital, disbogota, dismdo, pib_total, Violencia_48_a_53, conflicto,
         coca, homrates, desemp_fisc, categoria, g_prop, g_terreno, aptitud)


# import homicide data
#hom <- read.dta13("~/Box Sync/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/homicides colombia.dta") %>%
#  subset(select=c(codmpio,ano,homrate)) %>% 
#  reshape(idvar = "codmpio", timevar = "ano", direction = "wide")

hom <- read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/CEDE Panel/homicides colombia03-17.dta", convert.dates = F) %>%
  subset(select=c(codmpio,ano,homrate)) %>% 
  filter(as.numeric(as.character(ano))>2003) %>% 
  reshape(idvar = "codmpio", timevar = "ano", direction = "wide")
 
 

# import property tax data
pop <-  gen %>%
 filter(ano>=2000&ano<2016) %>%
  left_join(gob, by=c('ano','codmpio')) %>%
  mutate(tx = (y_corr_tribut_predial/pobl_tot)*1000, regal = (y_cap_regalias/pobl_tot)*1000
         #trib=(y_corr_tribut/pobl_tot)*1000,
         #transf = (y_cap_transf/pobl_tot)*1000 #, 
         #inst_inv = inv_fortinst/pobl_tot,
         #justice_inv =inv_en_justicia/pobl_tot
         ) %>% 
  select(codmpio, ano, tx,regal,
         desemp_fisc) %>%
  reshape(idvar = "codmpio", timevar = "ano", direction = "wide")


#ppc <- gen %>%
#  filter(ano>=2008&ano<2010) %>%
#  select(codmpio,ano,pib_total)%>%
#  reshape(idvar = "codmpio", timevar = "ano", direction = "wide")


# import political competition 2011
comp <- read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Political competition Colombia/competition_margin.dta") %>%
  filter(ano==2011|ano==2003) %>%
  dplyr::select (codmpio,mv,ano)%>%
  pivot_wider(id_cols = codmpio, 
              names_from = ano, 
              values_from = c("mv"),
              names_prefix="comp") 


c07<-read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/Elecciones Colombia/Regionales/2007_Alcaldia.dta") %>%
  mutate(can=1) %>%
  dplyr::group_by(codmpio) %>%
  dplyr::summarise(cand07 = sum(can))

c11<-read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/Elecciones Colombia/Regionales/2011_Alcaldia.dta") %>%
  mutate(can=1) %>%
  dplyr::group_by(codmpio) %>%
  dplyr::summarise(cand11 = sum(can))


part<-read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Electoral Violence/JPR17/JPR17-0085 Final Submission/Data and scripts/finaldataJPR.dta") %>%
 filter(ano==2007|ano==2011) %>%
   select(codmpio, ano, competencia) %>%
  pivot_wider(id_cols = codmpio, 
              names_from = ano,
              values_from = c("competencia"),
              names_prefix="parties") 

inc<-read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/Elecciones Colombia/Regionales/2011_Alcaldia.dta") %>%
  group_by(codmpio) %>%
  arrange(desc(votos)) %>%
  slice(1) %>%
  # is party elected in 2011 paramilitary-friendly
  dplyr::mutate(par_friendly2011=ifelse(codpartido %in% c(1,2,34,35,155,163,165,195,198),1,0)) %>%
  dplyr::rename(elected2011=codpartido) %>%
  select(codmpio,elected2011,par_friendly2011) 



# violent groups
gen1<-read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/CEDE Panel/PANEL_CARACTERISTICAS_GENERALES.dta", convert.dates = F) %>% select(codmpio, ano)
muni2 <- read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/CEDE Panel/PANEL_CARACTERISTICAS_GENERALES.dta", convert.dates = F) %>% 
  select(codmpio, ano,pobl_tot)%>%
  filter(ano>1999&ano<2016&pobl_tot>0)

actors<-read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 2. Oil Palm and State-Building/Data/actors.dta", convert.dates = F) %>%
  cast(ano+codmpio~actor, sum) %>%
  left_join(muni2, by=c("codmpio","ano")) %>%
  mutate(Insurgents=Insurgents/pobl_tot*100000,
         Paramilitaries=Paramilitaries/pobl_tot*100000,
         `Criminal organizations`=`Criminal organizations`/pobl_tot*100000) %>%
  right_join(gen1, by=c('codmpio','ano')) %>%
  dplyr::select(ano, codmpio, Insurgents, Paramilitaries, `Criminal organizations`) %>%
  filter(ano>1999&ano<2016) %>%
  dplyr::rename(guerrilla=Insurgents, paras=Paramilitaries, criminal=`Criminal organizations`) %>%
  mutate(bac=paras+criminal) %>%
  pivot_wider(id_cols = codmpio, 
              names_from = ano, 
              values_from = c("guerrilla","paras","criminal","bac")) %>%
  replace(is.na(.), 0)

 

 


#selective ass
#muni2 <- read.dta13("~/Box Sync/Data/Colombia/CEDE Panel/PANEL_CARACTERISTICAS_GENERALES.dta") %>% 
#  filter(ano==2015) %>% select(codmpio, pobl_tot)

#all <- readxl::read_xlsx("~/Box Sync/Data/cnmh - violence against civic leaders and consequences/victimas_asesinatos_selectivos.xlsx") %>%
#  filter(ano>=2005 & ano<=2011) %>%
#  mutate(ev=1) %>%
#  filter(ano>0&codmpio>0) %>%
#  dplyr::group_by(codmpio, ano) %>% 
#  dplyr::summarise(event=sum(ev))%>%
#  arrange(ano) %>%
#  left_join(muni2, by="codmpio") %>%
#  mutate(event=event/pobl_tot*10000) %>%
#  pivot_wider(id_cols = codmpio,
#              names_from = ano, 
#              values_from = c("event"),
#              names_prefix="all") 
  
#all[is.na(all)]<-0



# land
land <- agr %>%
  filter(ano>=2003&ano<=2012) %>%
  dplyr::select(codmpio, ano, informalidad, g_prop, g_terreno, vigencia) %>%
  pivot_wider(id_cols = codmpio, 
              names_from = ano, 
              values_from = c("informalidad", "g_prop","g_terreno")) 

land1 <- read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/cadaster_upd.dta") 

#data_wide1<-left_join(data_wide1,land, by='codmpio')

#jud ineff
jud <- haven::read_dta("~/Dropbox/Legal Capacity/Data/Data_Falses Positives paper/Data/FPMunyear.dta")  %>%
  dplyr::select(year,M_code,justice_percent) %>%
  pivot_wider(id_cols = M_code, 
              names_from = year, 
              values_from = c("justice_percent"),
              names_prefix="just") %>%
  dplyr::rename(codmpio=M_code)


#historical state
load("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/AER - State capacity/Fundacion_social_data.RData")
S_statepresence <- S_statepresence %>%
  select(V27,V4,V5,V3,V6,V18) %>%
  dplyr::rename(codmpio=V27, police=V4, courts=V5, pol_insp=V3, notary=V6, instruments=V18)

C_colonial <- C_colonial %>%
  select(V1,V2,V3,V4,V5) %>%
  dplyr::rename(codmpio=V5, crown=V1,nonmilcrown=V2,colonialstate=V3,citystatus=V4)

 

#hom - monthly
#muni <- read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/CEDE Panel/PANEL_CARACTERISTICAS_GENERALES.dta") %>% 
#  filter(ano %in% c(2007,2008,2009,2010,2011,2012,2013,2014,2015)) %>% select(codmpio, ano, pobl_tot) %>%
#  dplyr::rename(year=ano)

#hmdail<-read.dta13("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/Microdatos_Homicidios_2003-2017.dta", convert.dates = F)%>%
#  group_by(codmpio, fecha)%>%
#  dplyr::summarise(hom = sum(n_homicidios)) %>%
#  mutate(year = year(fecha),
 #        month = month(fecha),
 #        day = day(fecha))%>%
#  group_by(codmpio, year, month)%>%
#  dplyr::summarise(hom = sum(hom)) %>%
#  filter(year>=2007&year<=2015) %>%
#  left_join(muni,by=c("codmpio","year")) %>%
#  mutate(hom=(hom/pobl_tot)*100000) %>% select(-pobl_tot)%>%

#pivot_wider(id_cols = c("codmpio"), 
#            names_from = c("year","month"),
#            values_from = c("hom"),
#            names_prefix="hom")
#hmdail[is.na(hmdail)]<-0




#despl
#desp <- readxl::read_xlsx("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/Reporte Indices de Intensidad y Presion.xlsx", skip =1, 
 #                         col_names = c("t","ano","codmpio","depto","mpio",
#                                        "exp","rec","pob","int_desp","pres_desp"), sheet = 2) 
#desp <- desp %>%
#  dplyr::select(ano,codmpio,exp,int_desp) %>%  
#  mutate(codmpio = as.numeric(codmpio))%>%
#pivot_wider(id_cols = c("codmpio"), 
#            names_from = c("ano"),
#            values_from = c("exp", "int_desp"))

#coca in hectares
cocahs <- readxl::read_xls("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/Coca_2001_2010.xls") %>%
  dplyr::rename(codmpio=codmun) %>% filter(year==2006) %>% select(codmpio,Coca_ha) 


 

###########################
####  carreri dube    #####
###########################

setwd("~/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/Carreri & Dube -Colombia data/")
# in wide format
dube_carrieri <- read.delim("Carreri_Dube_replication_main.tab") %>%
  dplyr::rename(codmpio=origmun,ano=year) %>%
  filter(ano %in% c(2007)) %>%
  select(codmpio,para_mayor,para_mayor_acemoglu)



 
#lights <- read.dta13("/Users/camilo/Library/Mobile Documents/com~apple~CloudDocs/Data/Colombia/endogenous taxation/LIGHT92_13.dta") %>%
#  pivot_wider(id_cols = c("codmpio"), 
#              names_from = c("ano"),
#              values_from = c("light_mean", "light_std"))


### CATASTRO ACT
cat_act <- read.dta13("~/Dropbox/Legal Capacity/Data/Catastro Compilado 2000-2012.dta") %>% 
  #select(-municipio) %>% 
  left_join(gen, by=c('codmpio','ano')) %>% 
  mutate(reza=ano-vigencia_rur_fabio) %>% 
  select(codmpio,ano,reza) %>% 
  pivot_wider(id_cols = codmpio, 
              names_from = ano, 
              values_from = c("reza"),
              names_prefix = "reza_") %>% 
  mutate(cad_0407=(reza_2004+reza_2005+
                     reza_2006+reza_2007)/4,
         cad_lag= reza_2005,
         cad_0809=(reza_2008+reza_2009)/2,
         cat=ifelse(reza_2009==1,1,0)) %>% 
  select(codmpio,cad_0407,cad_0809, cad_lag, cat)

     
data_wide <- left_join(dat_new, covars, by=c('codmpio')) %>%
  left_join(cat_act, by=c('codmpio')) %>%
  left_join(pop, by=c('codmpio')) %>%
 left_join(hom, by=c('codmpio')) %>%
  left_join(comp, by=c('codmpio')) %>%
  left_join(actors, by=c('codmpio')) %>%
  left_join(land, by=c('codmpio')) %>%
  left_join(land1, by=c('codmpio')) %>%
  left_join(c07, by=c('codmpio')) %>%
  left_join(c11, by=c('codmpio')) %>%
  left_join(part, by=c('codmpio')) %>%
  left_join(inc, by=c('codmpio')) %>%
  left_join(cocahs, by='codmpio') %>%
  left_join(dube_carrieri, by='codmpio') %>%
  #left_join(all, by=c('codmpio')) %>%
 # left_join(hmdail, by=c('codmpio')) %>%
#  left_join(desp, by=c('codmpio')) %>%
#  left_join(ppc, by=c('codmpio')) %>%
#  left_join(lights, by=c('codmpio')) %>%
  left_join(jud, by=c('codmpio')) %>%
  left_join(S_statepresence, by=c('codmpio')) %>%
  left_join(C_colonial, by=c('codmpio')) %>%
  transform(popdens=pobl_tot/areaoficialkm2) %>%
  mutate(reelected=ifelse(data_wide$codigo_partido_1==data_wide$elected2011,1,0)) %>%
 
#============================= 
#   recode outcome variables
#=============================

####################
#### homicides  #### 
####################
mutate(h_0407=(homrate.2004+homrate.2005+homrate.2006+homrate.2007)/4,
       h_0811=(homrate.2008+homrate.2009+homrate.2010+homrate.2011)/4) %>%
#       h_0811=(homrate.2008+homrate.2009+homrate.2010+homrate.2011)/4,
#       h_1215=(homrate.2012+homrate.2013+homrate.2014+homrate.2015)/4,
#       h_0815=(homrate.2008+homrate.2009+homrate.2010+homrate.2011+
#              homrate.2012+homrate.2013+homrate.2014+homrate.2015)/8) %>%
  

####################
####    taxes   #### 
####################
mutate(tx_0407=(tx.2004+tx.2005+tx.2006+tx.2007)/4,
       tx_0811=(tx.2008+tx.2009+tx.2010+tx.2011)/4,
       tx_1215=(tx.2012+tx.2013+tx.2014+tx.2015)/4,
       tx_0815=(tx.2008+tx.2009+tx.2010+tx.2011+
                tx.2012+tx.2013+tx.2014+tx.2015)/8) %>%
       
 

############################
####    displacement    #### 
############################
#mutate(des_0407=(int_desp_2004+int_desp_2005+int_desp_2006+int_desp_2007)/4,
#       des_0811=(int_desp_2008+int_desp_2009+int_desp_2010+int_desp_2011)/4,
#       des_1215=(int_desp_2012+int_desp_2013+int_desp_2014+int_desp_2015)/4,
#       des_0815=(int_desp_2008+int_desp_2009+int_desp_2010+int_desp_2011+
#                 int_desp_2012+int_desp_2013+int_desp_2014+int_desp_2015)/8) %>%



####################
####    just   #### 
####################
mutate(just_0407=(just2004+just2005+just2006+just2007)/4,
       just_0809=(just2008+just2009)/2) %>%
  
  
  

 
  
############################
####  property rights   #### 
############################
# dummy if cadaster was updated anytime between 08 and 09
mutate(#cat=ifelse(rezago_catastral2009==1,1,0),
      # cad_0407=(rezago_catastral2004+rezago_catastral2005+
       #         rezago_catastral2006+rezago_catastral2007)/4,
      # cad_0809=(rezago_catastral2008+data_wide$rezago_catastral2009)/2,
       
       val_0407=(avaluo_rur_pcrur2004+avaluo_rur_pcrur2005+
                      avaluo_rur_pcrur2006+avaluo_rur_pcrur2007)/4,
       val_0809=(avaluo_rur_pcrur2008+avaluo_rur_pcrur2009)/2,
       
       inf_0407=(informalidad_2004+informalidad_2005+
                informalidad_2006+informalidad_2007)/4,
       inf_0809=(informalidad_2008+informalidad_2009)/2) %>%
  
  



  
  
############################
####     violent groups   #### 
############################ 
mutate(para_0407=(bac_2004+bac_2005+bac_2006+bac_2007)/4,
       guer_0407=(guerrilla_2004+guerrilla_2005+guerrilla_2006+guerrilla_2007)/4,
    para_0811=(bac_2008+bac_2009+bac_2010+bac_2011)/4,
       guer_0811=(guerrilla_2008+guerrilla_2009+guerrilla_2010+guerrilla_2011)/4) %>%
  
############################
####     gdp per cap    #### 
############################ 
#mutate(gdp_0809=(pib_total.2008+pib_total.2009)/2) %>%
  
  
############################
####     royalties    #### 
####     transfers    #### 
####     investment    #### 
############################ 
mutate(royal_0811=(regal.2008+regal.2009+regal.2010+regal.2011)/4,
      # trans = (transf.2008+transf.2009+transf.2010+transf.2011)/4,
      # inst0811 = (inst_inv.2008+inst_inv.2009+inst_inv.2010)/3,
      # inst = (inv_fortinst.2008+inv_fortinst.2009+inv_fortinst.2010)/3,
       desemp = (desemp_fisc.2008+desemp_fisc.2009+desemp_fisc.2010+desemp_fisc.2011)/4,
       desemp0407 = (desemp_fisc.2004+desemp_fisc.2005+desemp_fisc.2006+desemp_fisc.2007)/4) %>% 

mutate(
       jud_lag=just2005)

data_wide$Coca_ha[is.na(data_wide$Coca_ha)]<-0
data_wide$coca_hec<-data_wide$Coca_ha/data_wide$areaoficialkm2





###########################
####     sample      #####
###########################

cc_data <- data_wide %>% 
  
  mutate(mv=abs(mv)) %>% mutate(progw=ifelse(codigo_partido_1_1+codigo_partido_2_1+codigo_partido_34_1+
                                               codigo_partido_35_1+codigo_partido_155_1+codigo_partido_163_1+
                                               codigo_partido_165_1+codigo_partido_195_1+codigo_partido_198_1==1,1,0),
                                progl=ifelse(codigo_partido_1_2+codigo_partido_2_2+codigo_partido_34_2+
                                               codigo_partido_35_2+codigo_partido_155_2+codigo_partido_163_2+
                                               codigo_partido_165_2+codigo_partido_195_2+codigo_partido_198_2==1,1,0)) %>%
  mutate(mv1=ifelse(progl ==1, mv*-1,mv*1)) %>%  
  mutate(share1=ifelse(progl+progw==1, mv1*1,NA)) %>% 
  
 #placebo share - liberal & conservative 
  mutate(mv=abs(mv)) %>% mutate(progw=ifelse(codigo_partido_1_1+codigo_partido_2_1==1,1,0),
                                progl=ifelse(codigo_partido_1_2+codigo_partido_2_2==1,1,0)) %>%
  mutate(mv2=ifelse(progl ==1, mv*-1,mv*1)) %>%  
  mutate(share2=ifelse(progl+progw==1, mv2*1,NA)) %>% 
  
  # no liberal
  mutate(mv=abs(mv)) %>% mutate(progw=ifelse(codigo_partido_2_1+codigo_partido_34_1+
                                               codigo_partido_35_1+codigo_partido_155_1+codigo_partido_163_1+
                                               codigo_partido_165_1+codigo_partido_195_1+codigo_partido_198_1==1,1,0),
                                progl=ifelse(codigo_partido_2_2+codigo_partido_34_2+
                                               codigo_partido_35_2+codigo_partido_155_2+codigo_partido_163_2+
                                               codigo_partido_165_2+codigo_partido_195_2+codigo_partido_198_2==1,1,0)) %>%
  mutate(mv3=ifelse(progl ==1, mv*-1,mv*1)) %>%  
  mutate(share3=ifelse(progl+progw==1, mv3*1,NA)) 



## select variables

cc_data <- cc_data %>%  
  mutate(para_friendly=ifelse(is.na(share1),0,1)) %>% 
  select(codmpio,municipio,coddepto,codigo_partido_1,prop_1,codigo_partido_2,prop_2,para_friendly,share1,
         areaoficialkm2,altura,disbogota,dismdo,pib_percapita,y_transf_nal,desemp_fisc,popdens,aptitud, colonialstate,
         conflicto,Violencia_48_a_53,cad_lag,jud_lag,para_0407,guer_0407,para_0811,guer_0811,police,coca,courts,h_0407,tx_0407,comp2011,
         parties2011,cand11,reelected,para_mayor,tx_0811,tx_1215,tx.2012,tx.2013,tx.2014,tx.2015,cad_0809,val_0809,inf_0809,just_0809,royal_0811,
         coca_hec) %>% 
  dplyr::rename(winner=codigo_partido_1,loser=codigo_partido_2,
         winner_share=prop_1,loser_share=prop_2)
 
labelled::var_label(cc_data) <- NULL



save(cc_data, file="/Users/camilo/Library/Mobile Documents/com~apple~CloudDocs/Final paper - criminal collusion and state capacity/nietomatiz - data/crimcollusion_colombia_main.rda")

#save(data_wide, file="/Users/camilo/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/parapol_data.rda")
#save(data_wide, file="/Users/camilo/Box Sync/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/parapol_data_no_liberal.rda")





