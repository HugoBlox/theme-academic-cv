
library(tidyverse)
load("/Users/camilo/Box Sync/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/parapol_data.rda")
data_wide1 <- data_wide %>% filter(codigo_partido_1 %in% c(1,2,34,35,155,163,165,195,198)|
  codigo_partido_2 %in% c(1,2,34,35,155,163,165,195,198)) %>%  filter(th_1+th_2==1) 
data_wide2 <- data_wide %>% filter(codigo_partido_1 %in% c(2,34,35,155,163,165,195,198)|
  codigo_partido_2 %in% c(2,34,35,155,163,165,195,198)) %>%  filter(th_1+th_2==1) 

#covs <- cbind(data_wide1$altura,data_wide1$discapital,data_wide1$areaoficialkm2)

covs <- cbind(log(data_wide1$popdens+1), log(data_wide1$aptitud+1),  
              log(data_wide1$areaoficialkm2+1))

covs <- cbind(log(data_wide2$popdens+1), log(data_wide2$aptitud+1),  
              log(data_wide2$areaoficialkm2+1))


setwd("/Users/camilo/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence")

#============================= 
#     manipulation test
#=============================

rdd <- rddensity(X = data_wide1$share1, all = T, fitselect = "unrestricted", 
                 vce="jackknife");summary(rdd)

png("density test.png", width = 5, height = 4, units = 'in', res = 300)
rdplotdensity(rdd, data_wide1$share1)
dev.off()

 

# histogram forcing var
png("mv_hist.png", width = 5, height = 4, units = 'in', res = 300)
ggplot(data_wide1, aes(share1))+
  geom_histogram(bins=30, alpha=.7)+
  geom_vline(xintercept = 0, color="red", size=.2)+
  labs(x="Vote margin", y="")+theme_bw()
dev.off()


#============================= 
#    covariate balance 
#=============================
#intervals
interval1 <- -qnorm((1-0.95)/2)  # 95% multiplier

# local linear specification
summary(bt_1<-rdrobust(y = data_wide1$homrates, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri",covs=NULL, all = T))
summary(bt0<-rdrobust(y = data_wide1$tx_0407, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri",covs=NULL, all = T))
summary(bt1<-rdrobust(y = data_wide1$altura, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri",covs=NULL, all = T))
summary(bt2<-rdrobust(y = data_wide1$areaoficialkm2, x = data_wide1$share1, c = 0, p=1, vce = "nn",
                      kernel="tri", covs=NULL, all = T))
summary(bt3<-rdrobust(y = data_wide1$disbogota, x = data_wide1$share1, c = 0, p=1, vce = "nn",
                      kernel="tri",covs=NULL, all = T))
summary(bt4<-rdrobust(y = data_wide1$dismdo, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri",covs=NULL, all = T))
summary(bt5<-rdrobust(y = log(data_wide1$pib_percapita+1), x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt6<-rdrobust(y = log(data_wide1$desemp_fisc+1), x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt7<-rdrobust(y = log(data_wide1$y_transf_nal+1), x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt8<-rdrobust(y = data_wide1$popdens, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt9<-rdrobust(y = data_wide1$aptitud, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt10<-rdrobust(y = data_wide1$conflicto, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt11<-rdrobust(y = data_wide1$Violencia_48_a_53, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt12<-rdrobust(y = data_wide1$paras_2006, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt13<-rdrobust(y = data_wide1$guerrilla_2006, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt14<-rdrobust(y = data_wide1$bac_2006, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                      kernel="tri", covs=NULL, all = T))
summary(bt15<-rdrobust(y = data_wide1$police, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt16<-rdrobust(y = data_wide1$coca, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt17<-rdrobust(y = data_wide1$courts, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))
summary(bt18<-rdrobust(y = data_wide1$notary, x = data_wide1$share1, c = 0, p=1, vce = "nn", 
                       kernel="tri", covs=NULL, all = T))


#ols - full sample
data_wide1$treat <-ifelse(data_wide1$share1>0,1,0)
summary(bt_1.full<-lm_robust(homrates~share1*treat, data=data_wide1))
summary(bt0.full<-lm_robust(tx_0407~share1*treat, data=data_wide1))
summary(bt1.full<-lm_robust(altura~share1*treat, data=data_wide1))
summary(bt2.full<-lm_robust(areaoficialkm2~share1*treat, data=data_wide1))
summary(bt3.full<-lm_robust(disbogota~share1*treat, data=data_wide1))
summary(bt4.full<-lm_robust(dismdo~share1*treat, data=data_wide1))
summary(bt5.full<-lm_robust(log(data_wide1$pib_percapita+1)~share1*treat, data=data_wide1))
summary(bt6.full<-lm_robust(log(data_wide1$desemp_fisc+1)~share1*treat, data=data_wide1))
summary(bt7.full<-lm_robust(log(data_wide1$y_transf_nal+1)~share1*treat, data=data_wide1))
summary(bt8.full<-lm_robust(popdens~share1*treat, data=data_wide1))
summary(bt9.full<-lm_robust(aptitud~share1*treat, data=data_wide1))
summary(bt10.full<-lm_robust(conflicto~share1*treat, data=data_wide1))
summary(bt11.full<-lm_robust(Violencia_48_a_53~share1*treat, data=data_wide1))
summary(bt12.full<-lm_robust(paras_2006~share1*treat, data=data_wide1))
summary(bt13.full<-lm_robust(guerrilla_2006~share1*treat, data=data_wide1))
summary(bt14.full<-lm_robust(bac_2006~share1*treat, data=data_wide1))
summary(bt15.full<-lm_robust(police~share1*treat, data=data_wide1))
summary(bt16.full<-lm_robust(coca~share1*treat, data=data_wide1))
summary(bt17.full<-lm_robust(courts~share1*treat, data=data_wide1))
#summary(bt18.full<-lm_robust(notary~share1*treat, data=data_wide1))


#frame
balance <- data.frame(Var =    c('Homicide rates', 'Property taxation 04-07', 'Altitude','Area km2', 'Distance to Bogotá','Distance to market',
                                 'Per capita GDP','Fiscal performance','National transfers', 'Population density',
                                 'Soil quality', 'Land conflicts 1901-31', 'Violence 1948-43', 'Paramilitary actions',
                                 'Guerrilla actions','Criminal actions', 'Police station', 'Coca', 'Courts'),
                      Estimate =   c(bt_1$coef[3],bt0$coef[3],bt1$coef[3],bt2$coef[3],bt3$coef[3],bt4$coef[3],bt5$coef[3],bt6$coef[3],bt7$coef[3],
                                     bt8$coef[3],bt9$coef[3],bt10$coef[3],bt11$coef[3],bt12$coef[3],bt13$coef[3],bt14$coef[3],
                                     bt15$coef[3],bt16$coef[3],bt17$coef[3]),
                      pvalue =   c(bt_1$pv[3],bt0$pv[3],bt1$pv[3],bt2$pv[3],bt3$pv[3],bt4$pv[3],bt5$pv[3],bt6$pv[3],bt7$pv[3],bt8$pv[3],bt9$pv[3],
                                   bt10$pv[3],bt11$pv[3],bt12$pv[3],bt13$pv[3],bt14$pv[3],bt15$pv[3],bt16$pv[3],bt17$pv[3]),
                      SE =  c(bt_1$se[3],bt0$se[3],bt1$se[3],bt2$se[3],bt3$se[3],bt4$se[3],bt5$se[3],bt6$se[3],bt7$se[3],bt8$se[3],bt9$se[3],
                              bt10$se[3],bt11$se[3],bt12$se[3],bt13$se[3],bt14$se[3], bt15$se[3], bt16$se[3], bt17$se[3]))
balance$Var <- factor(balance$Var, ordered(balance$Var))
balance$Specification <- "Local"

balance1 <- data.frame(Var =    c('Homicide rates', 'Property taxation 04-07', 'Altitude','Area km2', 'Distance to Bogotá','Distance to market',
                                  'Per capita GDP','Fiscal performance','National transfers', 'Population density',
                                  'Soil quality', 'Land conflicts 1901-31', 'Violence 1948-43', 'Paramilitary actions',
                                  'Guerrilla actions','Criminal actions', 'Police station', 'Coca', 'Courts'),
                       Estimate =  c(bt_1.full$coefficients[3],bt0.full$coefficients[3],bt1.full$coefficients[3],bt2.full$coefficients[3],bt3.full$coefficients[3],bt4.full$coefficients[3],bt5.full$coefficients[3],bt6.full$coefficients[3],bt7.full$coefficients[3],
                                     bt8.full$coefficients[3],bt9.full$coefficients[3],bt10.full$coefficients[3],bt11.full$coefficients[3],bt12.full$coefficients[3],bt13.full$coefficients[3],bt14.full$coefficients[3],
                                     bt15.full$coefficients[3],bt16.full$coefficients[3],bt17.full$coefficients[3]),
                       pvalue =   c(bt_1.full$p.value[3],bt0.full$p.value[3],bt1.full$p.value[3],bt2.full$p.value[3],bt3.full$p.value[3],bt4.full$p.value[3],bt5.full$p.value[3],bt6.full$p.value[3],bt7.full$p.value[3],
                                    bt8.full$p.value[3],bt9.full$p.value[3],bt10.full$p.value[3],bt11.full$p.value[3],bt12.full$p.value[3],bt13.full$p.value[3],bt14.full$p.value[3],
                                    bt15.full$p.value[3],bt16.full$p.value[3],bt17.full$p.value[3]),
                       SE =   c(bt_1.full$std.error[3],bt0.full$std.error[3],bt1.full$std.error[3],bt2.full$std.error[3],bt3.full$std.error[3],bt4.full$std.error[3],bt5.full$std.error[3],bt6.full$std.error[3],bt7.full$std.error[3],
                                bt8.full$std.error[3],bt9.full$std.error[3],bt10.full$std.error[3],bt11.full$std.error[3],bt12.full$std.error[3],bt13.full$std.error[3],bt14.full$std.error[3],
                                bt15.full$std.error[3],bt16.full$std.error[3],bt17.full$std.error[3]))
balance1$Var <- factor(balance1$Var, ordered(balance$Var))
balance1$Specification <- "Full"

balance.data <- rbind(balance,balance1)


png("para_balancetest.png", 
    width = 5, height = 5, units = 'in', res = 300)
balance.data%>%
ggplot()+ 
  geom_point(aes(x = pvalue, y=Var, color=Specification, shape=Specification), 
             lwd = 2, position = position_dodge(width = 0.5))+
  geom_vline(xintercept = 0.05, colour = "red", lty = 2, lwd=0.3)+
  scale_color_manual(values=c("darkorange", "olivedrab"))+
  xlim(0,1)+
  ylab('')+xlab('p-value')+theme_bw()+
  theme(plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(hjust = 0),
        axis.text.y = element_text(hjust = 0),
        legend.position="bottom")
dev.off()







#=========================================
###              bandwidth              ###
#==========================================

#intervals
interval1 <- -qnorm((1-0.95)/2)  # 95% multiplier


# matrix to store homicide estimates
store_bw1 <- as.data.frame(matrix(NA,34,3))
store_bw2 <- as.data.frame(matrix(NA,34,3))
store_bw3 <- as.data.frame(matrix(NA,34,3))


# Initiate loop for taxes 08-11
bandw <- sort(c(seq(.04,.2,by=.005), 0.078)) #calonico's optimal bw: 
for (i in 1:length(bandw)) {
  # Estimate model
  summary(bw_loop1 <- rdrobust(y=(data_wide1$tx_0811+1), x = data_wide1$share1, c =0, p=1,h=bandw[i],b=.16,vce = "nn", 
                                kernel="tri", covs=NULL, all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw1[[i,1]] <- bw_loop1$coef[3]
  store_bw1[[i,2]] <- bw_loop1$se[3]
  store_bw1[[i,3]] <- bw_loop1$pv[3]
  store_bw1$c <- bandw
  store_bw1$c<-round(store_bw1$c, digits = 4)
}
colnames(store_bw1)<-c('coef','se','pv','c')
store_bw1$bw<-ifelse(store_bw1$c==.078,1,0)



# Initiate loop for taxes 04-07
bandw <- sort(c(seq(.04,.2,by=.005), .085))  #calonico's optimal bw: .085
for (i in 1:length(bandw)) {
  # Estimate model
  summary(bw_loop2 <- rdrobust(y= (data_wide1$tx_0407), x = data_wide1$share1, c =0, p=1,h=bandw[i],b=.164,vce = "nn", 
                               bwselect = "mserd", kernel="tri", all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw2[[i,1]] <- bw_loop2$coef[3]
  store_bw2[[i,2]] <- bw_loop2$se[3]
  store_bw2[[i,3]] <- bw_loop2$pv[3]
  store_bw2$c <- bandw
  store_bw2$c<-round(store_bw2$c, digits = 4)
}
colnames(store_bw2)<-c('coef','se','pv', 'c')
store_bw2$bw<-ifelse(store_bw2$c==.085,1,0)




# Initiate loop for taxes 04-07 COVS
bandw <- sort(c(seq(.04,.2,by=.005), .098)) #calonico's optimal bw: .1
for (i in 1:length(bandw)) {
  # Estimate model
  summary(bw_loop2 <- rdrobust(y= (data_wide1$tx_0407), x = data_wide1$share1, c =0, p=1,h=bandw[i],b=.169, covs=covs,vce = "nn", 
                               bwselect = "mserd", kernel="tri", all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw3[[i,1]] <- bw_loop2$coef[3]
  store_bw3[[i,2]] <- bw_loop2$se[3]
  store_bw3[[i,3]] <- bw_loop2$pv[3]
  store_bw3$c <- bandw
  store_bw3$c<-round(store_bw3$c, digits = 4)
}
colnames(store_bw3)<-c('coef','se','pv', 'c')
store_bw3$bw<-ifelse(store_bw3$c==.098,1,0)




# Initiate loop for taxes 08-15
bandw <- sort(c(seq(.04,.2,by=.005), .089)) #calonico's optimal bw: .078
for (i in 1:length(bandw)) {
  # Estimate model
  summary(bw_loop3 <- rdrobust(y=log(data_wide1$tx_0815+1), x = data_wide1$mv, c =0, p=1,h=bandw[i],b=.164,vce = "nn", 
                               bwselect = "mserd", kernel="tri", covs=covs, all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw3[[i,1]] <- bw_loop3$coef[3]
  store_bw3[[i,2]] <- bw_loop3$se[3]
  store_bw3[[i,3]] <- bw_loop3$pv[3]
  store_bw3$c <- bandw
  store_bw3$c<-round(store_bw3$c, digits = 4)
}
colnames(store_bw3)<-c('coef','se','pv', 'c')
store_bw3$bw<-ifelse(store_bw3$c==.089,1,0)



# bandwidth plot
png("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/bw_placebo1_para_tx.png", 
    width = 6, height = 5, units = 'in', res = 200)
store_bw1 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.4)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-70,50)+xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
dev.off()

png("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/bw_placebo2_para_tx0407.png", 
    width = 6, height = 5, units = 'in', res = 200)
store_bw2 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.4)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-70,20)+xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
dev.off()


png("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/bw_placebo2_para_tx0407_covs.png", 
    width = 6, height = 5, units = 'in', res = 200)
store_bw3 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.2)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-70,20)+ xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
dev.off()


#########
## homicide rates
# create bandwidths
####
store_bw4 <- as.data.frame(matrix(NA,34,3))
store_bw5 <- as.data.frame(matrix(NA,34,3))
store_bw6 <- as.data.frame(matrix(NA,34,3))

# Initiate loop for hom 08-11
bandwh <- sort(c(seq(.04,.2,by=.005), .111)) #calonico's optimal bw: .1
for (i in 1:length(bandwh)) {
  # Estimate model
  summary(bw_loop4 <- rdrobust(y=(data_wide1$h_0811+1), x = data_wide1$mv, c =0, p=1,h=bandwh[i],b=.202,vce = "nn", 
                               bwselect = "mserd", kernel="tri", covs=covs, all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw4[[i,1]] <- bw_loop4$coef[3]
  store_bw4[[i,2]] <- bw_loop4$se[3]
  store_bw4[[i,3]] <- bw_loop4$pv[3]
  store_bw4$c <- bandwh
  store_bw4$c<-round(store_bw4$c, digits = 4)
}
colnames(store_bw4)<-c('coef','se','pv','c')
store_bw4$bw<-ifelse(store_bw4$c==.111,1,0)




# Initiate loop for hom 04-07
bandwh <- sort(c(seq(.04,.2,by=.005), .118)) #calonico's optimal bw: .107
for (i in 1:length(bandwh)) {
  # Estimate model
  summary(bw_loop5 <- rdrobust(y=(data_wide1$h_0407+1), x = data_wide1$mv, c =0, p=1,h=bandwh[i],b=.228,vce = "nn", 
                               bwselect = "mserd", kernel="tri", covs=covs, all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw5[[i,1]] <- bw_loop5$coef[3]
  store_bw5[[i,2]] <- bw_loop5$se[3]
  store_bw5[[i,3]] <- bw_loop5$pv[3]
  store_bw5$c <- bandwh
  store_bw5$c<-round(store_bw5$c, digits = 4)
}
colnames(store_bw5)<-c('coef','se','pv', 'c')
store_bw5$bw<-ifelse(store_bw5$c==.118,1,0)




# Initiate loop for hom 08-15
bandwh <- sort(c(seq(.04,.2,by=.005), .119)) #calonico's optimal bw: .132
for (i in 1:length(bandwh)) {
  # Estimate model
  summary(bw_loop6 <- rdrobust(y=(data_wide1$h_1215+1), x = data_wide1$mv, c=0, p=1,h=bandwh[i],b=.2,vce = "nn", 
                               bwselect = "mserd", kernel="tri", covs=covs, all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw6[[i,1]] <- bw_loop6$coef[3]
  store_bw6[[i,2]] <- bw_loop6$se[3]
  store_bw6[[i,3]] <- bw_loop6$pv[3]
  store_bw6$c <- bandwh
  store_bw6$c<-round(store_bw6$c, digits = 4)
}
colnames(store_bw6)<-c('coef','se','pv', 'c')
store_bw6$bw<-ifelse(store_bw6$c==.119,1,0)


     
# bandwidth plot
png("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/bw_placebo4_para_hom.png", 
    width = 6, height = 5, units = 'in', res = 200)
store_bw4 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.4)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-70,70)+ xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
dev.off()

png("bw_placebo5_para_hom0407.png", width = 6, height = 3, units = 'in', res = 200)
store_bw5 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.4)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-70,70)+ xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
dev.off()

png("bw_placebo6_para_hom.png", width = 6, height = 5, units = 'in', res = 200)
store_bw6 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.2)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-40,65)+ xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
dev.off()















#########
## displacement
# create bandwidths
####
store_bw7 <- as.data.frame(matrix(NA,33,3))
store_bw8 <- as.data.frame(matrix(NA,33,3))
store_bw9 <- as.data.frame(matrix(NA,34,3))

# Initiate loop for disp 08-11
bandwd <- sort(c(seq(.04,.2,by=.005))) #calonico's optimal bw: .095
for (i in 1:length(bandwd)) {
  # Estimate model
  summary(bw_loop7 <- rdrobust(y=data_wide1$des_0811, x = data_wide1$mv, c =0, p=1,h=bandwd[i],b=.176,vce = "nn", 
                               bwselect = "mserd", kernel="tri", covs=covs, all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw7[[i,1]] <- bw_loop7$coef[3]
  store_bw7[[i,2]] <- bw_loop7$se[3]
  store_bw7[[i,3]] <- bw_loop7$pv[3]
  store_bw7$c <- bandwd
  store_bw7$c<-round(store_bw7$c, digits = 4)
}
colnames(store_bw7)<-c('coef','se','pv','c')
store_bw7$bw<-ifelse(store_bw7$c==.095,1,0)




# Initiate loop for disp 12-15
bandwd <- sort(c(seq(.04,.2,by=.005))) #calonico's optimal bw: .125
for (i in 1:length(bandwd)) {
  # Estimate model
  summary(bw_loop8 <- rdrobust(y=data_wide1$des_1215, x = data_wide1$mv, c =0, p=1,h=bandwd[i],b=.210,vce = "nn", 
                               bwselect = "mserd", kernel="tri", covs=covs, all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw8[[i,1]] <- bw_loop8$coef[3]
  store_bw8[[i,2]] <- bw_loop8$se[3]
  store_bw8[[i,3]] <- bw_loop8$pv[3]
  store_bw8$c <- bandwd
  store_bw8$c<-round(store_bw8$c, digits = 4)
}
colnames(store_bw8)<-c('coef','se','pv', 'c')
store_bw8$bw<-ifelse(store_bw8$c==.125,1,0)




# Initiate loop for disp 08-15
bandwd <- sort(c(seq(.04,.2,by=.005), .108)) #calonico's optimal bw: .108
for (i in 1:length(bandwd)) {
  # Estimate model
  summary(bw_loop9 <- rdrobust(y=data_wide1$des_0815, x = data_wide1$mv, c=0, p=1,h=bandwh[i],b=.192,vce = "nn", 
                               bwselect = "mserd", kernel="tri", covs=covs, all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw9[[i,1]] <- bw_loop9$coef[3]
  store_bw9[[i,2]] <- bw_loop9$se[3]
  store_bw9[[i,3]] <- bw_loop9$pv[3]
  store_bw9$c <- bandwd
  store_bw9$c<-round(store_bw9$c, digits = 4)
}
colnames(store_bw9)<-c('coef','se','pv', 'c')
store_bw9$bw<-ifelse(store_bw9$c==.108,1,0)




# bandwidth plot
png("bw_placebo7_para_disp.png", width = 5, height = 4, units = 'in', res = 200)
store_bw7 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.2)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-20,30)+xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
dev.off()

png("bw_placebo8_para_dis.png", width = 6, height = 5, units = 'in', res = 200)
store_bw8 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.2)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-35,45)+ xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
dev.off()

png("bw_placebo9_para_dis.png", width = 6, height = 5, units = 'in', res = 200)
store_bw9 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.2)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-35,45)+ xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
dev.off()












#============================= 
#      cutoff placebo 
#=============================
interval2 <- -qnorm((1-0.95)/2)  # 95% multiplier
cutoff <- sort(c(seq(-.3,.3, by=.04),0))


# matrix to store taxes estimates
store.t <- as.data.frame(matrix(NA,17,3))
colnames(store.t)<-c('coef','se','pv')

# Initiate loop for taxes #
for (i in 1:length(cutoff)) {
  # Estimate model
  summary(tx_loop <- rdrobust(data_wide1$tx_0811, x = data_wide1$share1, c = cutoff[i], p=1, vce = "nn", 
                               bwselect = "mserd", kernel="tri",  all = T))
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store.t[[i,1]] <- tx_loop$coef[3]
  store.t[[i,2]] <- tx_loop$se[3]
  store.t[[i,3]] <- tx_loop$pv[3]
  store.t$c <- cutoff
  store.t$zero<-ifelse(store.t$c==0,1,0)
  
}
 
# cutoff placebo plot
png("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/cutoff_pl_tx.png", 
    width = 6, height = 4, units = 'in', res = 300)
store.t %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval2,
                    ymax = coef + se*interval2, color=factor(zero), lwd=factor(zero)), width=.15)+
  scale_color_manual(values=c("gray50", "blue"))+
  scale_size_manual(values=c(.4,.7))+ylim(-200,300)+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none",
        axis.text.x = element_text( size=7))
dev.off()

 
#----------------------------------------------------------------------------------#
















# outcome 2 - microscopic
# homicide frame
dv.h <- data_wide1[, c("hom2006_1","hom2006_2","hom2006_3","hom2006_4", "hom2006_5","hom2006_6",
                       "hom2006_7","hom2006_8","hom2006_9","hom2006_10","hom2006_11","hom2006_12",
                       "hom2007_1","hom2007_2","hom2007_3","hom2007_4", "hom2007_5","hom2007_6",
                      "hom2007_7","hom2007_8","hom2007_9","hom2007_10","hom2007_11","hom2007_12",
                      "hom2008_1","hom2008_2","hom2008_3","hom2008_4", "hom2008_5","hom2008_6",
                      "hom2008_7","hom2008_8","hom2008_9","hom2008_10","hom2008_11","hom2008_12",
                      "hom2009_1","hom2009_2","hom2009_3","hom2009_4", "hom2009_5","hom2009_6",
                      "hom2009_7","hom2009_8","hom2009_9","hom2009_10","hom2009_11","hom2009_12",
                      "hom2010_1","hom2010_2","hom2010_3","hom2010_4", "hom2010_5","hom2010_6",
                      "hom2010_7","hom2010_8","hom2010_9","hom2010_10","hom2010_11","hom2010_12",
                      "hom2011_1","hom2011_2","hom2011_3","hom2011_4", "hom2011_5","hom2011_6",
                      "hom2011_7","hom2011_8","hom2011_9","hom2011_10","hom2011_11","hom2011_12",
                      "hom2012_1","hom2012_2","hom2012_3","hom2012_4", "hom2012_5","hom2012_6",
                      "hom2012_7","hom2012_8","hom2012_9","hom2012_10","hom2012_11","hom2012_12",
                      "hom2013_1","hom2013_2","hom2013_3","hom2013_4", "hom2013_5","hom2013_6",
                      "hom2013_7","hom2013_8","hom2013_9","hom2013_10","hom2013_11","hom2013_12",
                      "hom2014_1","hom2014_2","hom2014_3","hom2014_4", "hom2014_5","hom2014_6",
                      "hom2014_7","hom2014_8","hom2014_9","hom2014_10","hom2014_11","hom2014_12",
                      "hom2015_1","hom2015_2","hom2015_3","hom2015_4", "hom2015_5","hom2015_6",
                      "hom2015_7","hom2015_8","hom2015_9","hom2015_10","hom2015_11","hom2015_12")]


hom.est<-lapply(1:ncol(dv.h[1:120]), function(x)rdrobust(dv.h[,x], data_wide1$mv,
                                                         c = 0, p=1, vce = "nn",
                                                         bwselect = "mserd", kernel="tri", 
                                                         covs=NULL, all = T))
hom.frame<-data.frame(t(round(sapply(hom.est, function(x)cbind(x$coef[3], x$se[3], x$pv[3])), 3)))

colnames(hom.frame)[1:3]<-c("Coefficient","SE", "pv")
hom.frame$year <- zoo::as.yearmon(2006 + seq(0, 119)/12)
hom.frame$n <-1:120
hom.frame$p <-ifelse(hom.frame$pv<.05,1,0)
hom.frame$p_9 <-ifelse(hom.frame$pv<.1,1,0)



#intervals
interval2 <- -qnorm((1-0.95)/2)  # 95% multiplier

# homicide plot
png("hom_plot_monthly.png", width = 7.5, height = 5, units = 'in', res = 200)
hom.frame %>%
  filter(n<37) %>%
  mutate(year = fct_reorder(as.factor(year), as.numeric(as.character(n)))) %>%
  ggplot(aes(y = as.factor(year), x = Coefficient)) +
  ylab('')+
  geom_errorbarh(aes( xmin = Coefficient - SE*interval2, 
                      xmax = Coefficient + SE*interval2, height = 0.2, color=factor(p)),
                 size=.5) +  scale_color_manual(values=c("gray60", "red2"))+
  geom_hline(yintercept = c(22,25), color="gray30", linetype=2)+
  geom_point() +scale_y_discrete(breaks = c("Jan 2006", "Jan 2007","Oct 2007","Jan 2008","Dec 2008")) +
  theme_bw() + xlab('') + coord_flip() + xlim(-30,30)+
  geom_vline(xintercept = 0, colour = gray(1/2), lty = 2)+
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none") +
  annotate(geom = c("text"), x = c(20,20), y = c(17,27.5), label = c("Election","Beginning \nof term"), hjust = "left", color="blue")+
  annotate(geom = "curve", x = c(20, 20), y = c(20,27), xend = c(20,20), yend = c(22,25), color="red", 
           curvature = 0, arrow = arrow(length = unit(2, "mm"))
  )
dev.off()



  
  
  
  
png("hom_plot_monthly_all.png", width = 6, height = 4, units = 'in', res = 300)
hom.frame %>%
  filter(n>24) %>%
  mutate(year = fct_reorder(as.factor(year), as.numeric(as.character(n)))) %>%
  ggplot(aes(y = as.factor(year), x = Coefficient), color="black", width=.4)+
  ylab('')+
  geom_errorbarh(aes( xmin = Coefficient - SE*interval2, 
                      xmax = Coefficient + SE*interval2, height = 0.5, color=factor(p_9))) +
  scale_color_manual(values=c("gray60", "red2"))+
  scale_size_manual(values=c(.4,.7))+
  geom_hline(yintercept = c(49), color="gray30", linetype=2)+
  geom_point(size=.5) +
  theme_bw() + xlab('') + coord_flip() + xlim(-30,30)+
  geom_vline(xintercept = 0, colour = gray(1/2), lty = 2)+
  theme(plot.title = element_text(hjust = 0.5), legend.position = "none") +
  scale_y_discrete(breaks = c("Jan 2007","Jan 2008","Jan 2009","Jan 2010",
                              "Jan 2011", "Jan 2012", "Jan 2013", "Jan 2014",
                              "Jan 2015")) 
dev.off()




 


##### quadratic polynomial 

# outcome 1 - property taxes 
summary(alt1<-rdrobust(log(data_wide1$tx_0811+1),data_wide1$mv,c=0,p=2,  
                       all = T, vce = "nn", kernel="tri", covs=covs,
                       bwselect = "mserd"))
summary(alt2<-rdrobust(log(data_wide1$tx_1215+1),data_wide1$mv,c=0,p=2,  
                       all = T, vce = "nn", kernel="tri",covs=covs,
                       bwselect = "mserd"))
summary(alt3<-rdrobust(log(data_wide1$tx_0815+1),data_wide1$mv,c=0,p=2,  
                       all = T, vce = "nn", kernel="tri",covs=covs,
                       bwselect = "mserd"))

# outcome 2 - homicide rates
summary(alt4<-rdrobust((data_wide1$h_0811),data_wide1$mv,c=0,p=2,  
                       all = T, vce = "hc0", kernel="tri",covs=covs,
                       bwselect = "mserd"))
summary(alt5<-rdrobust((data_wide1$h_1215),data_wide1$mv,c=0,p=2,  
                       all = T, vce = "hc0", kernel="tri",covs=covs,
                       bwselect = "mserd"))
summary(alt6<-rdrobust((data_wide1$h_0815),data_wide1$mv,c=0,p=2,  
                       all = T, vce = "hc0", kernel="tri",covs=covs,
                       bwselect = "mserd"))



m_alt1 <- t(data.frame(alt1$coef[3], alt1$se[3], alt1$pv[3], 
                       sum(alt1$N), sum(alt1$N_h), alt1$bws[1,1])); m_alt1
m_alt2 <- t(data.frame(alt2$coef[3], alt2$se[3], alt2$pv[3],
                       sum(alt2$N), sum(alt2$N_h), alt2$bws[1,1])); m_alt2
m_alt3 <- t(data.frame(alt3$coef[3], alt3$se[3], alt3$pv[3],
                       sum(alt3$N), sum(alt3$N_h), alt3$bws[1,1])); m_alt3

m_alt4 <- t(data.frame(alt4$coef[3], alt4$se[3], alt4$pv[3], 
                       sum(alt4$N), sum(alt4$N_h), alt4$bws[1,1])); m_alt4
m_alt5 <- t(data.frame(alt5$coef[3], alt5$se[3], alt5$pv[3],
                       sum(alt5$N), sum(alt5$N_h), alt5$bws[1,1])); m_alt5
m_alt6 <- t(data.frame(alt6$coef[3], alt6$se[3], alt6$pv[3],
                       sum(alt6$N), sum(alt6$N_h), alt6$bws[1,1])); m_alt6
cbind(m_alt1, m_alt2, m_alt3,m_alt4, m_alt5, m_alt6)
options(digits = 3)








#### towns of less than 100,000 inhabitants
summary(tx1<-rdrobust((data_wide$tx_0407+1),data_wide$mv,c=0,p=1,  
                      all = T, vce = "hc0", kernel="tri",
                      bwselect = "mserd", subset=(data_wide$pobl_tot<100000)))


png("~/Library/Mobile Documents/com~apple~CloudDocs/Article submission/2020 criminal coalitions and state consolidation/tax_rdplot.png", 
    width = 6, height = 4, units = 'in', res = 300) 
rdplot(log(data_wide1$tx_0811+1),data_wide1$mv,c=0,  
       x.lim = c(-.3,.3),  
       x.label = "Vote margin", y.label ="Property taxes",
       title = "")
dev.off()

png("~/Box Sync/Article submission/2020 criminal coalitions and state consolidation/hom_rdplot.png", 
    width = 6, height = 4, units = 'in', res = 300) 
rdplot((data_wide$h_0815),data_wide$mv,c=0, p=2,
       x.lim = c(-.3,.3), 
       x.label = "Vote margin", y.label ="Homicide Rates",
       title = "")
dev.off()




m_tx1 <- t(data.frame(tx1$coef[3], tx1$se[3], tx1$pv[3], 
                      sum(tx1$N), sum(tx1$N_h), tx1$bws[1,1])); m_tx1
m_tx2 <- t(data.frame(tx2$coef[3], tx2$se[3], tx2$pv[3],
                      sum(tx2$N), sum(tx2$N_h), tx2$bws[1,1])); m_tx2
m_tx3 <- t(data.frame(tx3$coef[3], tx3$se[3], tx3$pv[3],
                      sum(tx3$N), sum(tx3$N_h), tx3$bws[1,1])); m_tx3

m_h4 <- t(data.frame(h4$coef[3], h4$se[3], h4$pv[3], 
                     sum(h4$N), sum(h4$N_h), h4$bws[1,1])); m_h4
m_h5 <- t(data.frame(h5$coef[3], h5$se[3], h5$pv[3],
                     sum(h5$N), sum(h5$N_h), h5$bws[1,1])); m_h5
m_h6 <- t(data.frame(h6$coef[3], h6$se[3], h6$pv[3],
                     sum(h6$N), sum(h6$N_h), h6$bws[1,1])); m_h6
cbind(m_tx1, m_tx2, m_tx3, m_h4, m_h5, m_h6)
options(digits = 3) 

















################################################
################################################
##                rd  plots                   ##
##                  main                      ##
################################################
################################################


# set wd
rd.data <- subset(data_wide1) %>% mutate(tx=log(tx_0811+1))
rd.data2 <- rd.data

#=========================
#         homicides
#========================

# make the binned averages, first the bins to the left
count <- 1
bin.size <- .02
binx.left <- vector(length=length(seq(-.2, 0, bin.size)))
biny.left <- vector(length=length(binx.left))
last <- -.02
for(j in seq(-2, 0, bin.size)) {
  biny.left[count] <- mean(rd.data$tx[rd.data$mv >= j-bin.size & rd.data$mv < j], na.rm=T)
  binx.left[count] <- (j+last)/2
  last <- j
  count <- count + 1
}

# now the bins on the right
count <- 1
bin.size <- .02
binx.right <- vector(length=length(seq(0,.2, bin.size)))
biny.right <- vector(length=length(binx.right))
last <- 0.2
for(j in seq(0,2, bin.size)) {
  biny.right[count] <- mean(rd.data$tx[rd.data$mv >= j-bin.size & rd.data$mv < j], na.rm=T)
  binx.right[count] <- (j+last)/2
  last <- j
  count <- count + 1
}


temp1 <- data.frame(cbind(binx.left, biny.left))
temp2 <- data.frame(cbind(binx.right, biny.right))
colnames(temp2) <- c("binx.left", "biny.left")
temp <- rbind(temp1, temp2)

rd.data<- select(rd.data, mv, tx) %>% dplyr::rename(binx.left=mv, biny.left=tx)
 


ggplot(data=temp, aes(x=binx.left, y =  biny.left)) +
  geom_point(data=subset(temp, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 4.5) +
  geom_point(data=subset(temp, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 4.5) +
  #geom_point(data=subset(rd.data, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 1) +
  #geom_point(data=subset(rd.data, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 1) +
  geom_vline(xintercept = 0) +
  geom_smooth(data=subset(rd.data, binx.left >= 0&binx.left <= 2),method = "loess",formula = y ~ poly(x, 2), se = TRUE, size = 1.5, fill="blue", color = "gray10", span = 1, alpha = .4)  +
  geom_smooth(data=subset(rd.data, binx.left <= .001&binx.left >= -2),method = "loess",formula = y ~ poly(x, 2),se = TRUE, size = 1.5, fill="red", color = "gray10", span = 1, alpha = .4)  +
  coord_cartesian(xlim = c(-.3, .3))+
  labs(x="Margin of Vote", y="Property Taxes") +
  theme_bw()+
  theme(text = element_text(hjust = 0.5, family="Palatino", size=12))
ggsave("tax_rdplot.pdf", height = 5, width = 6)
ggsave("tax_rdplot.png", height = 5, width = 6)


#=========================
#         homicides
#========================

# make the binned averages, first the bins to the left
count <- 1
bin.size <- .02
binx.left <- vector(length=length(seq(-.2, 0, bin.size)))
biny.left <- vector(length=length(binx.left))
last <- -.02
for(j in seq(-2, 0, bin.size)) {
  biny.left[count] <- mean(rd.data2$h_0811[rd.data2$mv >= j-bin.size & rd.data2$mv < j], na.rm=T)
  binx.left[count] <- (j+last)/2
  last <- j
  count <- count + 1
}

# now the bins on the right
count <- 1
bin.size <- .02
binx.right <- vector(length=length(seq(0,.2, bin.size)))
biny.right <- vector(length=length(binx.right))
last <- 0.2
for(j in seq(0,2, bin.size)) {
  biny.right[count] <- mean(rd.data2$h_0811[rd.data2$mv >= j-bin.size & rd.data2$mv < j], na.rm=T)
  binx.right[count] <- (j+last)/2
  last <- j
  count <- count + 1
}


temp1 <- data.frame(cbind(binx.left, biny.left))
temp2 <- data.frame(cbind(binx.right, biny.right))
colnames(temp2) <- c("binx.left", "biny.left")
temp <- rbind(temp1, temp2)

rd.data2<- select(rd.data2, mv, h_0811) %>% dplyr::rename(binx.left=mv, biny.left=h_0811)



ggplot(data=temp, aes(x=binx.left, y =  biny.left)) +
  geom_point(data=subset(temp, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 4.5) +
  geom_point(data=subset(temp, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 4.5) +
  #geom_point(data=subset(rd.data2, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 1) +
  #geom_point(data=subset(rd.data2, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 1) +
  geom_vline(xintercept = 0) +
  geom_smooth(data=subset(rd.data2, binx.left >= 0&binx.left <= 2),method = "loess",formula = y ~ poly(x, 2), se = TRUE, size = 1.5, fill="blue", color = "gray10", span = 1, alpha = .4)  +
  geom_smooth(data=subset(rd.data2, binx.left <= 0.001&binx.left >= -2),method = "loess",formula = y ~ poly(x, 2),se = TRUE, size = 1.5, fill="red", color = "gray10", span = 1, alpha = .4)  +
  coord_cartesian(xlim = c(-.3, .3), ylim = c(-10, 100))+
  labs(x="Margin of Vote", y="Homicide rates") +
  theme_bw()+
  theme(text = element_text(hjust = 0.5, family="Palatino", size=12))
ggsave("hom_rdplot.pdf", height = 5, width = 6)
ggsave("hom_rdplot.png", height = 5, width = 6)

















################################################
################################################
##                rd  plots                   ##
##                2012-2015                   ##
################################################
################################################


# set wd
rd.data <- data_wide1
rd.data2 <- data_wide1

# make the binned averages, first the bins to the left
count <- 1
bin.size <- .02
binx.left <- vector(length=length(seq(-.2, 0, bin.size)))
biny.left <- vector(length=length(binx.left))
last <- -.02
for(j in seq(-2, 0, bin.size)) {
  biny.left[count] <- mean(rd.data$tx_1215[rd.data$mv >= j-bin.size & rd.data$mv < j], na.rm=T)
  binx.left[count] <- (j+last)/2
  last <- j
  count <- count + 1
}

# now the bins on the right
count <- 1
bin.size <- .02
binx.right <- vector(length=length(seq(0,.2, bin.size)))
biny.right <- vector(length=length(binx.right))
last <- 0.2
for(j in seq(0,2, bin.size)) {
  biny.right[count] <- mean(rd.data$tx_1215[rd.data$mv >= j-bin.size & rd.data$mv < j], na.rm=T)
  binx.right[count] <- (j+last)/2
  last <- j
  count <- count + 1
}


temp1 <- data.frame(cbind(binx.left, biny.left))
temp2 <- data.frame(cbind(binx.right, biny.right))
colnames(temp2) <- c("binx.left", "biny.left")
temp <- rbind(temp1, temp2)

rd.data<- select(rd.data, mv, tx_1215) %>% dplyr::rename(binx.left=mv, biny.left=tx_1215)



ggplot(data=temp, aes(x=binx.left, y =  biny.left)) +
  geom_point(data=subset(temp, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 4.5) +
  geom_point(data=subset(temp, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 4.5) +
  #geom_point(data=subset(rd.data, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 1) +
  #geom_point(data=subset(rd.data, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 1) +
  geom_vline(xintercept = 0) +
  geom_smooth(data=subset(rd.data, binx.left >= 0&binx.left <= 2),method = "loess",formula = y ~ poly(x, 2), se = TRUE, size = 1.5, fill="blue", color = "gray10", span = 1, alpha = .4)  +
  geom_smooth(data=subset(rd.data, binx.left <= 0&binx.left >= -2),method = "loess",formula = y ~ poly(x, 2),se = TRUE, size = 1.5, fill="red", color = "gray10", span = 1, alpha = .4)  +
  coord_cartesian(xlim = c(-.3, .3))+ ylim(-50,250)+
  labs(x="Margin of Vote", y="Property Taxes") +
  theme_bw()+
  theme(text = element_text(hjust = 0.5, family="Palatino", size=12))
#ggsave("tax_rdplot.pdf", height = 5, width = 6)
ggsave("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/rdplot_tax1215.png", height = 5, width = 6)


#=========================
#         homicides
#========================

rd.data2 <- data_wide1

# make the binned averages, first the bins to the left
count <- 1
bin.size <- .02
binx.left <- vector(length=length(seq(-.2, 0, bin.size)))
biny.left <- vector(length=length(binx.left))
last <- -.02
for(j in seq(-2, 0, bin.size)) {
  biny.left[count] <- mean(rd.data2$h_1215[rd.data2$mv >= j-bin.size & rd.data2$mv < j], na.rm=T)
  binx.left[count] <- (j+last)/2
  last <- j
  count <- count + 1
}

# now the bins on the right
count <- 1
bin.size <- .02
binx.right <- vector(length=length(seq(0,.2, bin.size)))
biny.right <- vector(length=length(binx.right))
last <- 0.2
for(j in seq(0,2, bin.size)) {
  biny.right[count] <- mean(rd.data2$h_1215[rd.data2$mv >= j-bin.size & rd.data2$mv < j], na.rm=T)
  binx.right[count] <- (j+last)/2
  last <- j
  count <- count + 1
}


temp1 <- data.frame(cbind(binx.left, biny.left))
temp2 <- data.frame(cbind(binx.right, biny.right))
colnames(temp2) <- c("binx.left", "biny.left")
temp <- rbind(temp1, temp2)

rd.data2<- select(rd.data2, mv, h_1215) %>% dplyr::rename(binx.left=mv, biny.left=h_1215)



ggplot(data=temp, aes(x=binx.left, y =  biny.left)) +
  geom_point(data=subset(temp, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 4.5) +
  geom_point(data=subset(temp, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 4.5) +
  #geom_point(data=subset(rd.data2, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 1) +
  #geom_point(data=subset(rd.data2, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 1) +
  geom_vline(xintercept = 0) +
  geom_smooth(data=subset(rd.data2, binx.left >= 0&binx.left <= 2),method = "loess",formula = y ~ poly(x, 2), se = TRUE, size = 1.5, fill="blue", color = "gray10", span = 1, alpha = .4)  +
  geom_smooth(data=subset(rd.data2, binx.left <= 0&binx.left >= -2),method = "loess",formula = y ~ poly(x, 2),se = TRUE, size = 1.5, fill="red", color = "gray10", span = 1, alpha = .4)+
  coord_cartesian(xlim = c(-.3, .3), ylim = c(-10, 75))+
  labs(x="Margin of Vote", y="Homicide rates") +
  theme_bw()+
  theme(text = element_text(hjust = 0.5, family="Palatino", size=12))
#ggsave("hom_rdplot.pdf", height = 5, width = 6)
ggsave("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/rdplot_hom1215.png", height = 5, width = 6)

 










################################################
################################################
##                rd  plots                   ##
##        excluding liberal party             ##
################################################
################################################


# set wd
rd.data <- data_wide2
rd.data2 <- data_wide2

# make the binned averages, first the bins to the left
count <- 1
bin.size <- .02
binx.left <- vector(length=length(seq(-.2, 0, bin.size)))
biny.left <- vector(length=length(binx.left))
last <- -.02
for(j in seq(-2, 0, bin.size)) {
  biny.left[count] <- mean(rd.data$tx_0811[rd.data$mv >= j-bin.size & rd.data$mv < j], na.rm=T)
  binx.left[count] <- (j+last)/2
  last <- j
  count <- count + 1
}

# now the bins on the right
count <- 1
bin.size <- .02
binx.right <- vector(length=length(seq(0,.2, bin.size)))
biny.right <- vector(length=length(binx.right))
last <- 0.2
for(j in seq(0,2, bin.size)) {
  biny.right[count] <- mean(rd.data$tx_0811[rd.data$mv >= j-bin.size & rd.data$mv < j], na.rm=T)
  binx.right[count] <- (j+last)/2
  last <- j
  count <- count + 1
}


temp1 <- data.frame(cbind(binx.left, biny.left))
temp2 <- data.frame(cbind(binx.right, biny.right))
colnames(temp2) <- c("binx.left", "biny.left")
temp <- rbind(temp1, temp2)

rd.data<- select(rd.data, mv, tx_0811) %>% dplyr::rename(binx.left=mv, biny.left=tx_0811)



ggplot(data=temp, aes(x=binx.left, y =  biny.left)) +
  geom_point(data=subset(temp, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 4.5) +
  geom_point(data=subset(temp, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 4.5) +
  #geom_point(data=subset(rd.data, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 1) +
  #geom_point(data=subset(rd.data, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 1) +
  geom_vline(xintercept = 0) +
  geom_smooth(data=subset(rd.data, binx.left >= 0&binx.left <= 2),method = "loess",formula = y ~ poly(x, 2), se = TRUE, size = 1.5, fill="blue", color = "gray10", span = 1, alpha = .4)  +
  geom_smooth(data=subset(rd.data, binx.left <= 0&binx.left >= -2),method = "loess",formula = y ~ poly(x, 2),se = TRUE, size = 1.5, fill="red", color = "gray10", span = 1, alpha = .4)  +
  coord_cartesian(xlim = c(-.3, .3))+
  labs(x="Margin of Vote", y="Property Taxes") +
  theme_bw()+
  theme(text = element_text(hjust = 0.5, family="Palatino", size=12))
#ggsave("tax_rdplot.pdf", height = 5, width = 6)
ggsave("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/rdplot_tax_noliberal.png", 
       height = 5, width = 6)


#=========================
#         homicides
#========================

rd.data2 <- data_wide2

# make the binned averages, first the bins to the left
count <- 1
bin.size <- .02
binx.left <- vector(length=length(seq(-.2, 0, bin.size)))
biny.left <- vector(length=length(binx.left))
last <- -.02
for(j in seq(-2, 0, bin.size)) {
  biny.left[count] <- mean(rd.data2$h_0811[rd.data2$mv >= j-bin.size & rd.data2$mv < j], na.rm=T)
  binx.left[count] <- (j+last)/2
  last <- j
  count <- count + 1
}

# now the bins on the right
count <- 1
bin.size <- .02
binx.right <- vector(length=length(seq(0,.2, bin.size)))
biny.right <- vector(length=length(binx.right))
last <- 0.2
for(j in seq(0,2, bin.size)) {
  biny.right[count] <- mean(rd.data2$h_0811[rd.data2$mv >= j-bin.size & rd.data2$mv < j], na.rm=T)
  binx.right[count] <- (j+last)/2
  last <- j
  count <- count + 1
}


temp1 <- data.frame(cbind(binx.left, biny.left))
temp2 <- data.frame(cbind(binx.right, biny.right))
colnames(temp2) <- c("binx.left", "biny.left")
temp <- rbind(temp1, temp2)

rd.data2<- select(rd.data2, mv, h_0811) %>% dplyr::rename(binx.left=mv, biny.left=h_0811)



ggplot(data=temp, aes(x=binx.left, y =  biny.left)) +
  geom_point(data=subset(temp, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 4.5) +
  geom_point(data=subset(temp, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 4.5) +
  #geom_point(data=subset(rd.data2, binx.left >= 0&binx.left <= 2),color="royalblue2",alpha = .4, size = 1) +
  #geom_point(data=subset(rd.data2, binx.left <= 0&binx.left >= -2),color="tomato2",alpha = .4, size = 1) +
  geom_vline(xintercept = 0) +
  geom_smooth(data=subset(rd.data2, binx.left >= 0&binx.left <= 2),method = "loess",formula = y ~ poly(x, 2), se = TRUE, size = 1.5, fill="blue", color = "gray10", span = 1, alpha = .4)  +
  geom_smooth(data=subset(rd.data2, binx.left <= 0&binx.left >= -2),method = "loess",formula = y ~ poly(x, 2),se = TRUE, size = 1.5, fill="red", color = "gray10", span = 1, alpha = .4)+
  coord_cartesian(xlim = c(-.3, .3), ylim = c(-10, 75))+
  labs(x="Margin of Vote", y="Homicide rates") +
  theme_bw()+
  theme(text = element_text(hjust = 0.5, family="Palatino", size=12))
#ggsave("hom_rdplot.pdf", height = 5, width = 6)
ggsave("~/Box Sync/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/rdplot_hom_noliberal.png", height = 5, width = 6)














#### alternative bandwidths - yearly outcomes


#intervals
interval1 <- -qnorm((1-0.95)/2)  # 95% multiplier


# matrix to store homicide estimates
store_bw1 <- as.data.frame(matrix(NA,34,3))
store_bw2 <- as.data.frame(matrix(NA,34,3))
store_bw3 <- as.data.frame(matrix(NA,34,3))
store_bw4 <- as.data.frame(matrix(NA,34,3))


# Initiate loop for taxes 08-11
bandw1 <- sort(c(seq(.04,.2,by=.005), .09)) #calonico's optimal bw: .09
bandw2 <- sort(c(seq(.04,.2,by=.005), .092)) #calonico's optimal bw: .09
bandw3 <- sort(c(seq(.04,.2,by=.005), .088)) #calonico's optimal bw: .09
bandw4 <- sort(c(seq(.04,.2,by=.005), .091)) #calonico's optimal bw: .09

for (i in 1:length(bandw)) {
  # Estimate model
  summary(bw_loop1 <- rdrobust(y=log(data_wide1$tx.2008+1), x = data_wide1$mv, c =0, p=1,h=bandw[i],b=.159,vce = "nn", 
                               kernel="tri", covs=covs, all = T)) 
  summary(bw_loop2 <- rdrobust(y=log(data_wide1$tx.2009+1), x = data_wide1$mv, c =0, p=1,h=bandw[i],b=.170,vce = "nn", 
                               kernel="tri", covs=covs, all = T)) 
  summary(bw_loop3 <- rdrobust(y=log(data_wide1$tx.2010+1), x = data_wide1$mv, c =0, p=1,h=bandw[i],b=.157,vce = "nn", 
                               kernel="tri", covs=covs, all = T)) 
  summary(bw_loop4 <- rdrobust(y=log(data_wide1$tx.2011+1), x = data_wide1$mv, c =0, p=1,h=bandw[i],b=.168,vce = "nn", 
                               kernel="tri", covs=covs, all = T)) 
  # Extract 3rd row of rd_out() LC function (robust RDD estimate)
  # Place into loop holder
  store_bw1[[i,1]] <- bw_loop1$coef[3]
  store_bw1[[i,2]] <- bw_loop1$se[3]
  store_bw1[[i,3]] <- bw_loop1$pv[3]
  store_bw1$c <- bandw
  store_bw1$c<-round(store_bw1$c, digits = 4)
  
  store_bw2[[i,1]] <- bw_loop2$coef[3]
  store_bw2[[i,2]] <- bw_loop2$se[3]
  store_bw2[[i,3]] <- bw_loop2$pv[3]
  store_bw2$c <- bandw
  store_bw2$c<-round(store_bw2$c, digits = 4)
  
  store_bw3[[i,1]] <- bw_loop3$coef[3]
  store_bw3[[i,2]] <- bw_loop3$se[3]
  store_bw3[[i,3]] <- bw_loop3$pv[3]
  store_bw3$c <- bandw
  store_bw3$c<-round(store_bw3$c, digits = 4)
  
  store_bw4[[i,1]] <- bw_loop4$coef[3]
  store_bw4[[i,2]] <- bw_loop4$se[3]
  store_bw4[[i,3]] <- bw_loop4$pv[3]
  store_bw4$c <- bandw
  store_bw4$c<-round(store_bw4$c, digits = 4)
  
}

colnames(store_bw1)<-c('coef','se','pv','c')
colnames(store_bw2)<-c('coef','se','pv','c')
colnames(store_bw3)<-c('coef','se','pv','c')
colnames(store_bw4)<-c('coef','se','pv','c')

store_bw1$bw<-ifelse(store_bw1$c==.09,1,0)
store_bw2$bw<-ifelse(store_bw2$c==.092,1,0)
store_bw3$bw<-ifelse(store_bw3$c==.088,1,0)
store_bw4$bw<-ifelse(store_bw4$c==.091,1,0)



store_bw1 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.4)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-.07,.05)+xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))

store_bw2 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.4)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-.08,.05)+xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))

store_bw3 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.4)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-.07,.05)+xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))


store_bw4 %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(c), ymin = coef - se*interval1,
                    ymax = coef + se*interval1, color=factor(bw), lwd = factor(bw)), width=.4)+
  scale_color_manual(values=c("steelblue3", "blue"))+
  scale_size_manual(values=c(.4,.7))+
  geom_point(aes(x = factor(c), y = coef), lwd = 1.5, shape = 20)+
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)+
  ylim(-.07,.05)+xlab('') + ylab('') + theme_bw() +
  theme(plot.title = element_text(hjust = 0.5),legend.position = "none")+
  scale_x_discrete(breaks=seq(0.04, .2, by = .02))
