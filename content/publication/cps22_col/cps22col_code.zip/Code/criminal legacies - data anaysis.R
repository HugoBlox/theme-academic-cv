# required packages - install first
library(estimatr)
library(tidyverse)
library(rdrobust)



###################################################################
###################################################################
#
#    When the state becomes complicit: mayors, criminal actors, 
#   and the deliberate weakening of the local state in Colombia 
#
#                    Camilo Nieto-Matiz
#                 camilo.nieto-matiz@utsa.edu
###################################################################
###################################################################
 
 
# load dataframe
load("crimcollusion_colombia_main.rda")


# covariates
covs <- cbind(log(cc_data$popdens+1),  
              log(cc_data$coca_hec+1),  log(cc_data$aptitud+1))

covs1 <- cbind(log(cc_data$popdens+1),  
               log(cc_data$coca_hec+1),  log(cc_data$aptitud+1),
              log(cc_data$cat_lag+1),
              log(cc_data$inf_lag+1),
              log(cc_data$jud_lag+1))

  
ta <- cc_data %>% select(tx_0407,tx_0811,tx_1215)
stargazer::stargazer(ta,   omit.summary.stat = c("p25", "p75"))

ta <- cc_data %>% select(cad_0809,val_0809,inf_0809)
stargazer::stargazer(ta,   omit.summary.stat = c("p25", "p75"))

#=========================================
#            Property taxes
#=========================================

############################# 
###  Pre-treatment 04-07
#############################

summary(rdrobust((cc_data$tx_0407),cc_data$share1,c=0,p=1,  
                        all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$tx_0407),cc_data$share1,c=0,p=1,  
                      all = T, vce = "nn", kernel="tri",covs=covs))
summary(rdrobust((cc_data$tx_0407),cc_data$share1,c=0,p=1,  
                      all = T, vce = "nn", kernel="tri",covs=covs1))


############################# 
###       2008-2011
#############################

summary(rdrobust((cc_data$tx_0811),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$tx_0811),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=covs))
summary(rdrobust((cc_data$tx_0811),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=covs1))

summary(rdrobust((cc_data$tx_0811),cc_data$share1,c=0,p=2,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$tx_0811),cc_data$share1,c=0,p=2,  
                 all = T, vce = "nn", kernel="tri",covs=covs))
summary(rdrobust((cc_data$tx_0811),cc_data$share1,c=0,p=2,  
                 all = T, vce = "nn", kernel="tri",covs=covs1))

############################# 
###   effects over time
#############################

## 08-11
summary(rdrobust((cc_data$tx.2008),cc_data$share1,c=0,p=1,  
                      all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$tx.2009),cc_data$share1,c=0,p=1,  
                      all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$tx.2010),cc_data$share1,c=0,p=1,  
                      all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$tx.2011),cc_data$share1,c=0,p=1,  
                      all = T, vce = "nn", kernel="tri",covs=NULL))


## 12-15
summary(rdrobust((cc_data$tx.2012),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$tx.2013),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$tx.2014),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$tx.2015),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))



#=========================================
#            Mechanisms
#=========================================

############################# 
###   property rights
#############################

summary(rdrobust((cc_data$inf_0809),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$val_0809),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$cad_0809),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))

############################# 
### judicial inefficiency
#############################

summary(tx0<-rdrobust((cc_data$just_0809),cc_data$share1,c=0,p=1,  
                      all = T, vce = "nn", kernel="tri",covs=NULL))


############################# 
###   political competition
#############################

summary(rdrobust((cc_data$comp2011),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$parties2011),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$cand11),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))
summary(rdrobust((cc_data$reelected),cc_data$share1,c=0,p=1,  
                 all = T, vce = "nn", kernel="tri",covs=NULL))



#=========================================
#         Alternative explanations
#=========================================

############################# 
#     violent groups
#############################
summary(alt1<-rdrobust(log(cc_data$para_0811+1),cc_data$share1,c=0,p=1,  
                      all = T, vce = "nn", kernel="tri",  
                      bwselect = "mserd"))
summary(alt2<-rdrobust(log(cc_data$guer_0811+1),cc_data$share1,c=0,p=1,  
                      all = T, vce = "nn", kernel="tri",  
                      bwselect = "mserd"))


############################# 
#       transfers
#############################
summary(alt1<-rdrobust((cc_data$royal_0811+1),cc_data$share1,c=0,p=1,  
                       all = T, vce = "nn", kernel="tri", 
                       bwselect = "mserd"))

 




#============================= 
#    summary statistics
#=============================

sum.stats<-as.data.frame(sum.stats)
stargazer(sum.stats)
sum.stats <- as.data.frame(cc_data) %>%
  transform(pibperc=log(pib_percapita+1),
            desemp=log(cc_data$desemp_fisc+1),
            transf=log(cc_data$y_transf_nal+1)) %>%
  subset(select=c(share1, tx_0811, tx_1215, tx_0815,
                  cad_0809,inf_0809,val_0809,just_0809,
                  comp2011,parties2011,cand11,reelected,
                  homrates,altura, areaoficialkm2, disbogota, dismdo,
                  pibperc,desemp,transf,
                  popdens, aptitud, 
                  conflicto, Violencia_48_a_53, 
                  paras_2006,guerrilla_2006,bac_2006, coca)) %>%
  stargazer(title="Summary Statistics", digits = 1,
            covariate.labels = c('Vote margin', 
                                 'Property taxes 08-11','Property taxes 12-15', 'Property taxes 08-15', 
                                 'Cadaster age', 'Land informality', 'Land values', 'Judicial inefficiency',
                                 'Vote margin 2011', 'Number of parties 2011', 'Number of candidates 2011',
                                 'Incumbent party reelected', 'Homicide rates', 'Altitude', 'Area km2', 'Distance to Bogota', 'Distance to closest market', 
                                 'Per capita GDP', 'Fiscal performance', 'Transfers',
                                 'Population density', 'Soil quality', 'Land conflicts 1901-31', 'Violence 1948-43', 
                                 'Paramilitary actions', 'Guerrilla actions', 'Criminal actions', 'Coca'),
            omit.summary.stat = c("p25", "p75"))










#=========================================
###              2012-2015             ###
#==========================================

#intervals
interval1 <- -qnorm((1-0.95)/2)  # 95% multiplier
tx_fr <- data.frame(est = c(tx_y5$coef[3],tx_y6$coef[3],tx_y7$coef[3],tx_y8$coef[3],tx2$coef[3]),
                    se = c(tx_y5$se[3],tx_y6$se[3],tx_y7$se[3],tx_y8$se[3],tx2$se[3]),
                    year = c('2012', '2013', '2014', '2015', '2012-15'))


png("~/Library/Mobile Documents/com~apple~CloudDocs/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/overtime_tx1215.png", 
    width = 5, height = 4, units = 'in', res = 300)
tx_fr %>%
  mutate(year = fct_reorder(as.factor(year), as.numeric(as.character(year)))) %>%
  ggplot() +
  geom_errorbar(mapping=aes(x = factor(year), ymin = est - se*interval1,
                    ymax = est + se*interval1), width=.09, color="blue") +
  geom_point(aes(x = factor(year), y = est), 
             lwd = 2, position = position_dodge(width = 0.5)) +
  geom_hline(yintercept = 0, colour = "red", lty = 2, lwd=0.3)+
  ylim(-130,80)+
  ylab('')+xlab('')+theme_bw()+
  theme(plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(hjust = 0),
        axis.text.y = element_text(hjust = 0),
        legend.position="bottom")
dev.off()



png("~/Box Sync/Dissertation/Ch 3. Criminal legacies and state consolidation/Data - criminal legacies and violence/overtime_hom1215.png", 
    width = 5, height = 4, units = 'in', res = 300)
hom_fr <- data.frame(est = c(h_y5$coef[3],h_y6$coef[3],h_y7$coef[3],h_y8$coef[3],h2$coef[3]),
                     se = c(h_y5$se[3],h_y6$se[3],h_y7$se[3],h_y8$se[3],h2$se[3]),
                     year = c('2012', '2013', '2014', '2015', '2012-15'))
hom_fr%>%
  mutate(year = fct_reorder(as.factor(year), as.numeric(as.character(year)))) %>%
  ggplot()+ 
  geom_errorbar(aes(x = factor(year), ymin = est - se*interval1,
                    ymax = est + se*interval1), width=.09, color="blue") +
  geom_point(aes(x = factor(year), y = est), 
             lwd = 2, position = position_dodge(width = 0.5))+
  geom_hline(yintercept = 0, colour = "red", lty = 2, lwd=0.3)+
  ylim(-70,70)+
  ylab('')+xlab('')+theme_bw()+
  theme(plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(hjust = 0),
        axis.text.y = element_text(hjust = 0),
        legend.position="bottom")
dev.off()
